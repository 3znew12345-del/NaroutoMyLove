# تعليمات التركيب — تصميم الإعدادات الفاخر

هذا الزيب فيه نفس بنية مجلدات مشروعك بالضبط. فك الضغط في جذر المشروع
(المجلد اللي فيه NagramX/ و TMessagesProj/) واختر "استبدال/Overwrite"
عند السؤال عن الملفات الموجودة.

الملفات (7):
- NagramX/TMessagesProj/.../settings/NekoSettingsActivity.java   (تعديل)
- NagramX/TMessagesProj/.../ui/cells/GroupedTextCell.java        (تعديل)
- NagramX/TMessagesProj/.../ui/cells/RoundedSettingCell.java     (تعديل)
- NagramX/TMessagesProj/.../ui/cells/PremiumIconColors.java      (جديد)
- NagramX/TMessagesProj/.../ui/cells/PremiumSectionHeaderCell.java (جديد)
- NagramX/TMessagesProj/.../res/values/strings_nax.xml           (بدون تغيير، فقط تأكيد)
- TMessagesProj/.../org/telegram/ui/SettingsActivity.java        (تعديل)

بعد النسخ:
    ./gradlew assembleDebug

لو تفضل سكربت آلي بدل النسخ اليدوي، شغّل apply_changes.sh من مجلد
منفصل (الطريقة القديمة) — لكن هذا الزيب مصمم للنسخ المباشر فوق المشروع.
