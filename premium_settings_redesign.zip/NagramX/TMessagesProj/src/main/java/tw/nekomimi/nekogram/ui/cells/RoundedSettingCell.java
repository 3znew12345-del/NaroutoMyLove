package tw.nekomimi.nekogram.ui.cells;

import static org.telegram.messenger.AndroidUtilities.dp;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.RectF;
import android.view.MotionEvent;

import androidx.core.graphics.ColorUtils;

import org.telegram.messenger.LocaleController;
import org.telegram.tgnet.TLRPC;
import org.telegram.ui.ActionBar.Theme;
import org.telegram.ui.Components.CubicBezierInterpolator;
import org.telegram.ui.Components.RecyclerListView;
import org.telegram.ui.Components.UItem;
import org.telegram.ui.Components.UniversalAdapter;
import org.telegram.ui.Components.UniversalRecyclerView;
import org.telegram.ui.SettingsActivity;

/**
 * Premium, iOS-informed rounded card row used by the outer Settings list
 * (Account / Chat / Privacy / etc.). Replaces the app-wide gradient badge
 * icon with a flat single-tone squircle, tightens row rhythm, and gives
 * grouped cards a very slightly raised surface so groups read as distinct
 * cards against the page background rather than a flat continuation of it.
 *
 * Scoped entirely to this screen via a dedicated cell class + palette
 * (PremiumIconColors) so none of this leaks into the many other screens
 * that reuse the shared UItem/UniversalAdapter list system.
 */
public class RoundedSettingCell extends SettingsActivity.SettingCell {

    public enum Position {
        SINGLE, FIRST, MIDDLE, LAST
    }

    private static final float CORNER_RADIUS_DP = 14f;
    // Matches SettingCell's fixed 28dp icon slot (see addView(iconView, ...)
    // in the base class) — the badge must fill that exact box, not an
    // arbitrary size, or it'll clip or float inside a larger transparent hole.
    private static final float ICON_BADGE_RADIUS_DP = 9f;

    // Fixed, theme-independent divider — bypasses key_divider, which
    // resolves to near-black in the bundled dark theme (matching the
    // screen background) and is effectively invisible there.
    private static final int DIVIDER_COLOR_LIGHT = 0x14000000; // ~8% black — quieter than before
    private static final int DIVIDER_COLOR_DARK = 0x1FFFFFFF;  // ~12% white

    // Card surface is drawn a shade lighter/darker than the page so
    // grouped rows read as one raised card rather than blending into
    // the background, without relying on a drop shadow (shadows don't
    // read cleanly on near-black dark themes).
    private static final int CARD_TINT_DARK = 0x0FFFFFFF;  // +6% white lift over page bg
    private static final int CARD_TINT_LIGHT = 0x05000000; // -2% black over page bg

    private Position position = Position.MIDDLE;
    private boolean drawDivider = false;
    private final RectF rect = new RectF();
    private final Paint backgroundPaint = new Paint(Paint.ANTIALIAS_FLAG);
    private final Paint pressPaint = new Paint(Paint.ANTIALIAS_FLAG);
    private final Paint dividerPaint = new Paint(Paint.ANTIALIAS_FLAG);
    private final Paint iconBadgePaint = new Paint(Paint.ANTIALIAS_FLAG);
    private final RectF iconBadgeRect = new RectF();

    private float pressAlpha = 0f;
    private ValueAnimator pressAnimator;
    private final Theme.ResourcesProvider resourcesProvider;

    public RoundedSettingCell(Context context, Theme.ResourcesProvider resourcesProvider) {
        super(context, resourcesProvider);
        this.resourcesProvider = resourcesProvider;
        setWillNotDraw(false);
    }

    public void setPosition(Position position) {
        if (this.position != position) {
            this.position = position;
            invalidate();
        }
    }

    public void setDrawDivider(boolean drawDivider) {
        if (this.drawDivider != drawDivider) {
            this.drawDivider = drawDivider;
            invalidate();
        }
    }

    private int getThemedColor(int key) {
        return Theme.getColor(key, resourcesProvider);
    }

    private boolean isDark() {
        return resourcesProvider != null ? resourcesProvider.isDark() : Theme.isCurrentThemeDark();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                animatePress(true);
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                animatePress(false);
                break;
        }
        return super.onTouchEvent(event);
    }

    private void animatePress(boolean pressed) {
        if (pressAnimator != null) {
            pressAnimator.cancel();
        }
        float target = pressed ? 1f : 0f;
        pressAnimator = ValueAnimator.ofFloat(pressAlpha, target);
        pressAnimator.setDuration(pressed ? 90 : 180);
        pressAnimator.setInterpolator(pressed ? CubicBezierInterpolator.EASE_OUT : CubicBezierInterpolator.EASE_OUT_QUINT);
        pressAnimator.addUpdateListener(a -> {
            pressAlpha = (float) a.getAnimatedValue();
            invalidate();
        });
        pressAnimator.start();
    }

    @Override
    protected void dispatchDraw(Canvas canvas) {
        int w = getMeasuredWidth();
        int h = getMeasuredHeight();
        float r = dp(CORNER_RADIUS_DP);

        float topRadius = (position == Position.FIRST || position == Position.SINGLE) ? r : 0f;
        float bottomRadius = (position == Position.LAST || position == Position.SINGLE) ? r : 0f;

        rect.set(0, 0, w, h);
        int pageBg = getThemedColor(Theme.key_windowBackgroundGray);
        int cardTint = isDark() ? CARD_TINT_DARK : CARD_TINT_LIGHT;
        backgroundPaint.setColor(ColorUtils.compositeColors(cardTint, pageBg));
        drawRoundedRect(canvas, rect, topRadius, bottomRadius, backgroundPaint);

        if (pressAlpha > 0f) {
            pressPaint.setColor(getThemedColor(Theme.key_listSelector));
            pressPaint.setAlpha((int) (pressAlpha * 255));
            drawRoundedRect(canvas, rect, topRadius, bottomRadius, pressPaint);
        }

        super.dispatchDraw(canvas);

        if (drawDivider) {
            boolean dark = isDark();
            dividerPaint.setColor(dark ? DIVIDER_COLOR_DARK : DIVIDER_COLOR_LIGHT);
            // Inset to the title text start: 18dp leading margin + 30dp
            // badge + 18dp text gap = 66dp, matching the new 30dp badge.
            float inset = dp(66);
            canvas.drawLine(
                    LocaleController.isRTL ? 0 : inset,
                    h - 1,
                    w - (LocaleController.isRTL ? inset : 0),
                    h - 1,
                    dividerPaint
            );
        }
    }

    private void drawRoundedRect(Canvas canvas, RectF r, float topRadius, float bottomRadius, Paint paint) {
        float[] radii = new float[]{
                topRadius, topRadius,
                topRadius, topRadius,
                bottomRadius, bottomRadius,
                bottomRadius, bottomRadius
        };
        Path path = new Path();
        path.addRoundRect(r, radii, Path.Direction.CW);
        canvas.drawPath(path, paint);
    }

    /**
     * Factory for the outer Settings list only. Mirrors
     * {@link SettingsActivity.SettingCell.Factory} for the title/subtitle/
     * value contract, but resolves icon color through PremiumIconColors
     * (via item.longValue carrying an enum ordinal) instead of the
     * app-wide gradient palette, and paints a flat squircle instead of
     * the stock top/bottom gradient background.
     */
    public static class Factory extends UItem.UItemFactory<RoundedSettingCell> {
        static { setup(new Factory()); }

        @Override
        public RoundedSettingCell createView(android.content.Context context, RecyclerListView listView, int currentAccount, int classGuid, Theme.ResourcesProvider resourcesProvider) {
            return new RoundedSettingCell(context, resourcesProvider);
        }

        @Override
        public void bindView(android.view.View view, UItem item, boolean divider, UniversalAdapter adapter, UniversalRecyclerView listView) {
            RoundedSettingCell cell = (RoundedSettingCell) view;
            PremiumIconColors palette = PremiumIconColors.values()[(int) item.longValue];
            // Route through the stock set() call (keeps title/subtitle/
            // value + accessibility wiring identical to SettingCell) but
            // override the icon painting immediately after via the flat
            // badge helper, since SettingCell.set() only knows the
            // gradient Background drawable.
            cell.set(palette.bg, palette.bg, item.iconResId, item.text, item.subtext, item.textValue);
            cell.applyFlatIcon(palette);
            cell.setPosition(Position.values()[item.intValue]);
            cell.setDrawDivider(cell.position != Position.LAST && cell.position != Position.SINGLE);
        }

        public static UItem of(int id, PremiumIconColors palette, int icon, CharSequence title, Position position) {
            return of(id, palette, icon, title, null, null, position);
        }

        public static UItem of(int id, PremiumIconColors palette, int icon, CharSequence title, CharSequence subtitle, Position position) {
            return of(id, palette, icon, title, subtitle, null, position);
        }

        public static UItem of(int id, PremiumIconColors palette, int icon, CharSequence title, CharSequence subtitle, CharSequence value, Position position) {
            final UItem item = UItem.ofFactory(Factory.class);
            item.id = id;
            item.iconResId = icon;
            item.text = title;
            item.subtext = subtitle;
            item.textValue = value;
            item.longValue = palette.ordinal();
            item.intValue = position.ordinal();
            return item;
        }

        /**
         * Attach-menu bot row (e.g. the Wallet side-menu bot) rendered
         * through the same flat RoundedSettingCell styling as every other
         * row in the group, so its position ordinal (assigned later by
         * SettingsActivity.closeGroup) is interpreted consistently.
         */
        public static UItem ofBot(TLRPC.TL_attachMenuBot attachMenuBot, PremiumIconColors palette, int icon, Position position) {
            final UItem item = UItem.ofFactory(Factory.class);
            item.id = Long.hashCode(attachMenuBot.bot_id);
            item.object = attachMenuBot;
            item.iconResId = icon;
            item.text = attachMenuBot.short_name;
            item.longValue = palette.ordinal();
            item.intValue = position.ordinal();
            return item;
        }
    }

    /**
     * Repaints the icon as a flat squircle (rounded-rect badge, single
     * tone) with a tinted glyph, replacing the gradient Background the
     * base SettingCell.set() call installed. Kept as a separate pass
     * rather than overriding set() itself so this class stays a thin
     * skin over the stock cell rather than a fork of its layout logic.
     */
    private void applyFlatIcon(PremiumIconColors palette) {
        android.widget.ImageView iconView = getIconView();
        if (iconView == null) return;
        iconView.setBackground(new FlatBadgeDrawable(palette.bg));
        iconView.setColorFilter(new PorterDuffColorFilter(palette.fg, PorterDuff.Mode.SRC_IN));
    }

    /** Flat rounded-rect badge — replaces the gradient Background drawable. */
    private static class FlatBadgeDrawable extends android.graphics.drawable.Drawable {
        private final Paint paint = new Paint(Paint.ANTIALIAS_FLAG);
        private final RectF rectF = new RectF();

        FlatBadgeDrawable(int color) {
            paint.setColor(color);
        }

        @Override
        public void draw(Canvas canvas) {
            rectF.set(getBounds());
            float r = dp(ICON_BADGE_RADIUS_DP);
            canvas.drawRoundRect(rectF, r, r, paint);
        }

        @Override
        public void setAlpha(int alpha) {}
        @Override
        public void setColorFilter(android.graphics.ColorFilter colorFilter) {}
        @Override
        public int getOpacity() {
            return android.graphics.PixelFormat.TRANSPARENT;
        }
    }
}
