package tw.nekomimi.nekogram.ui.cells;

/**
 * Flat, muted icon badge palette for the redesigned Settings screens.
 *
 * Deliberately NOT reusing {@link org.telegram.ui.Components.IconBackgroundColors}
 * (the app-wide Material-style top/bottom gradient set) — that enum is
 * consumed elsewhere in the app and changing it would leak this screen's
 * styling everywhere. This palette is scoped to RoundedSettingCell /
 * GroupedTextCell only.
 *
 * Each entry is a single background/foreground pair:
 *  - bg:  a low-saturation, darkened tone used as the squircle fill
 *         (dark theme) — quiet enough to sit behind an icon without
 *         competing with the row text.
 *  - fg:  a brighter tint of the same hue for the icon glyph itself,
 *         giving enough contrast to read at 15-16dp without looking
 *         like a stock Material "badge".
 *
 * All values pre-computed for the dark theme this app ships with;
 * RoundedSettingCell/GroupedTextCell apply a light-mode variant via
 * ColorUtils at draw time (see FLAT ICON COLORS section in each cell).
 */
public enum PremiumIconColors {

    BLUE(0xFF1F2C3A, 0xFF6FB4F0),
    INDIGO(0xFF23263A, 0xFF8B93F0),
    VIOLET(0xFF2E2B3A, 0xFFB39CF0),
    TEAL(0xFF1C2E2C, 0xFF6FD9B8),
    GREEN(0xFF243228, 0xFF7FD99A),
    AMBER(0xFF362B1D, 0xFFE8B15C),
    ORANGE(0xFF3A2A1C, 0xFFF0A15E),
    RED(0xFF3A2626, 0xFFF0897E),
    ROSE(0xFF3A2430, 0xFFF08CAE),
    GRAY(0xFF262830, 0xFF9CA1AC);

    public final int bg;
    public final int fg;

    PremiumIconColors(int bg, int fg) {
        this.bg = bg;
        this.fg = fg;
    }
}
