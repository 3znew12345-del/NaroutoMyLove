package tw.nekomimi.nekogram.ui.cells;

import android.content.Context;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.TextView;

import org.telegram.messenger.AndroidUtilities;
import org.telegram.messenger.LocaleController;
import org.telegram.ui.ActionBar.Theme;
import org.telegram.ui.Components.LayoutHelper;
import org.telegram.ui.Components.RecyclerListView;
import org.telegram.ui.Components.UItem;
import org.telegram.ui.Components.UniversalAdapter;
import org.telegram.ui.Components.UniversalRecyclerView;

/**
 * Quiet, small-caps-weight section label placed above a grouped card
 * (Account / Chat / Privacy, Notifications / Data, etc.) — iOS-style
 * "eyebrow" header. Deliberately not using the stock bold-blue HeaderCell
 * from this screen's Neko sub-page, since that reads as a UI chrome
 * element rather than a soft section label appropriate for a premium
 * grouped-card layout.
 */
public class PremiumSectionHeaderCell extends FrameLayout {

    private final TextView textView;
    private final Theme.ResourcesProvider resourcesProvider;

    public PremiumSectionHeaderCell(Context context, Theme.ResourcesProvider resourcesProvider) {
        super(context);
        this.resourcesProvider = resourcesProvider;

        textView = new TextView(context);
        textView.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 13);
        textView.setTypeface(AndroidUtilities.getTypeface("fonts/rmedium.ttf"));
        textView.setEllipsize(TextUtils.TruncateAt.END);
        textView.setGravity((LocaleController.isRTL ? Gravity.RIGHT : Gravity.LEFT) | Gravity.CENTER_VERTICAL);
        addView(textView, LayoutHelper.createFrame(LayoutHelper.WRAP_CONTENT, LayoutHelper.WRAP_CONTENT, LocaleController.isRTL ? Gravity.RIGHT : Gravity.LEFT));
        updateColors();
    }

    public void updateColors() {
        // Fixed, theme-independent color — deliberately NOT
        // key_windowBackgroundWhiteGrayText2. That key resolves to
        // near-white at ~43% alpha in the bundled dark themes (it's
        // designed for gray text on a WHITE section background), which
        // on our dark premium card renders as a barely-visible ghost
        // label. See PremiumIconColors sibling comment for the same
        // class of bug this screen had with icon colors.
        boolean dark = resourcesProvider != null ? resourcesProvider.isDark() : Theme.isCurrentThemeDark();
        textView.setTextColor(dark ? 0xFF9BA1AC : 0xFF6D7178);
    }

    public void setText(CharSequence text) {
        textView.setText(text);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        // 18dp top / 8dp bottom: tight to the card below, generous gap
        // from the group above — the asymmetric spacing iOS uses so a
        // header visually "belongs" to the card underneath it, not the
        // one above it.
        setPadding(AndroidUtilities.dp(20), AndroidUtilities.dp(18), AndroidUtilities.dp(20), AndroidUtilities.dp(8));
        super.onMeasure(
                MeasureSpec.makeMeasureSpec(MeasureSpec.getSize(widthMeasureSpec), MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(AndroidUtilities.dp(34), MeasureSpec.EXACTLY)
        );
    }

    public static class Factory extends UItem.UItemFactory<PremiumSectionHeaderCell> {
        static { setup(new Factory()); }

        @Override
        public PremiumSectionHeaderCell createView(Context context, RecyclerListView listView, int currentAccount, int classGuid, Theme.ResourcesProvider resourcesProvider) {
            return new PremiumSectionHeaderCell(context, resourcesProvider);
        }

        @Override
        public void bindView(android.view.View view, UItem item, boolean divider, UniversalAdapter adapter, UniversalRecyclerView listView) {
            ((PremiumSectionHeaderCell) view).setText(item.text);
        }

        public static UItem of(CharSequence text) {
            final UItem item = UItem.ofFactory(Factory.class);
            item.text = text;
            return item;
        }
    }
}
