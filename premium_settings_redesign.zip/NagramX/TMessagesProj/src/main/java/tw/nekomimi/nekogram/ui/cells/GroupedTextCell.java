package tw.nekomimi.nekogram.ui.cells;

import static org.telegram.messenger.AndroidUtilities.dp;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;

import androidx.core.graphics.ColorUtils;

import org.telegram.messenger.LocaleController;
import org.telegram.ui.ActionBar.Theme;
import org.telegram.ui.Cells.TextCell;
import org.telegram.ui.Components.CubicBezierInterpolator;

/**
 * A drop-in replacement for {@link TextCell} used only by the NekoSettings
 * screen. Renders each row as part of a premium grouped card:
 *  - Rounded top corners on the first row of a group, rounded bottom
 *    corners on the last row, square in between (or all four on a
 *    single-row group).
 *  - A flat press-state background fade instead of the platform ripple.
 *  - Divider inset so it never crosses the rounded corner.
 *  - Card surface is a subtle lift over the page background (no drop
 *    shadow — shadows don't read cleanly on the app's dark theme).
 *
 * Deliberately NOT a change to the shared TextCell class, since that
 * class is used across the whole app — this keeps the visual change
 * scoped to the Settings screen only.
 */
public class GroupedTextCell extends TextCell {

    public enum Position {
        SINGLE, FIRST, MIDDLE, LAST
    }

    private static final float CORNER_RADIUS_DP = 14f;

    private static final int DIVIDER_COLOR_LIGHT = 0x14000000;
    private static final int DIVIDER_COLOR_DARK = 0x1FFFFFFF;

    private static final int CARD_TINT_DARK = 0x0FFFFFFF;
    private static final int CARD_TINT_LIGHT = 0x05000000;

    private Position position = Position.MIDDLE;
    private final RectF rect = new RectF();
    private final Paint backgroundPaint = new Paint(Paint.ANTIALIAS_FLAG);
    private final Paint pressPaint = new Paint(Paint.ANTIALIAS_FLAG);
    private final Paint dividerPaint = new Paint(Paint.ANTIALIAS_FLAG);

    private float pressAlpha = 0f;
    private ValueAnimator pressAnimator;
    private final Theme.ResourcesProvider resourcesProvider;

    public GroupedTextCell(Context context, Theme.ResourcesProvider resourcesProvider) {
        super(context, resourcesProvider);
        this.resourcesProvider = resourcesProvider;
        setWillNotDraw(false);
        // The card background is drawn manually (rounded), so the plain
        // rectangular background Telegram sets via setBackgroundColor()
        // in the adapter must be cleared to avoid a square edge showing
        // through behind the rounded corners.
        setBackgroundColor(0);
    }

    public void setPosition(Position position) {
        if (this.position != position) {
            this.position = position;
            invalidate();
        }
    }

    private int getThemedColor(int key) {
        return Theme.getColor(key, resourcesProvider);
    }

    private boolean isDark() {
        return resourcesProvider != null ? resourcesProvider.isDark() : Theme.isCurrentThemeDark();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                animatePress(true);
                break;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                animatePress(false);
                break;
        }
        return super.onTouchEvent(event);
    }

    private void animatePress(boolean pressed) {
        if (pressAnimator != null) {
            pressAnimator.cancel();
        }
        float target = pressed ? 1f : 0f;
        pressAnimator = ValueAnimator.ofFloat(pressAlpha, target);
        pressAnimator.setDuration(pressed ? 90 : 180);
        pressAnimator.setInterpolator(pressed ? CubicBezierInterpolator.EASE_OUT : CubicBezierInterpolator.EASE_OUT_QUINT);
        pressAnimator.addUpdateListener(a -> {
            pressAlpha = (float) a.getAnimatedValue();
            invalidate();
        });
        pressAnimator.start();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getMeasuredWidth();
        int h = getMeasuredHeight();
        float r = dp(CORNER_RADIUS_DP);

        float topRadius = (position == Position.FIRST || position == Position.SINGLE) ? r : 0f;
        float bottomRadius = (position == Position.LAST || position == Position.SINGLE) ? r : 0f;

        rect.set(0, 0, w, h);
        int pageBg = getThemedColor(Theme.key_windowBackgroundGray);
        int cardTint = isDark() ? CARD_TINT_DARK : CARD_TINT_LIGHT;
        backgroundPaint.setColor(ColorUtils.compositeColors(cardTint, pageBg));
        drawRoundedRect(canvas, rect, topRadius, bottomRadius, backgroundPaint);

        if (pressAlpha > 0f) {
            pressPaint.setColor(getThemedColor(Theme.key_listSelector));
            pressPaint.setAlpha((int) (pressAlpha * 255));
            drawRoundedRect(canvas, rect, topRadius, bottomRadius, pressPaint);
        }

        if (position == Position.FIRST || position == Position.MIDDLE) {
            dividerPaint.setColor(isDark() ? DIVIDER_COLOR_DARK : DIVIDER_COLOR_LIGHT);
            float inset = dp(68);
            canvas.drawLine(
                    LocaleController.isRTL ? 0 : inset,
                    h - 1,
                    w - (LocaleController.isRTL ? inset : 0),
                    h - 1,
                    dividerPaint
            );
        }
    }

    private void drawRoundedRect(Canvas canvas, RectF r, float topRadius, float bottomRadius, Paint paint) {
        float[] radii = new float[]{
                topRadius, topRadius,
                topRadius, topRadius,
                bottomRadius, bottomRadius,
                bottomRadius, bottomRadius
        };
        android.graphics.Path path = new android.graphics.Path();
        path.addRoundRect(r, radii, android.graphics.Path.Direction.CW);
        canvas.drawPath(path, paint);
    }
}
