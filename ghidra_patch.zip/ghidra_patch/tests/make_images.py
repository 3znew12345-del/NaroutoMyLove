#!/usr/bin/env python3
"""Builds multi.raw (AArch64, base 0x10000) with 5 functions. Needs: pip install keystone-engine"""
import subprocess, sys, os
from keystone import *
ks = Ks(KS_ARCH_ARM64, KS_MODE_LITTLE_ENDIAN)
BASE = 0x10000
# 0x0: clone of Java_cn_rjtool_mobile_G_v (GetArrayLength / GetByteArrayRegion / NEON compare), constants at 0x100 and 0x120
src0 = """
cbz x2, Lfalse1
sub sp, sp, #0x40
stp x29, x30, [sp, #0x30]
stp x19, x20, [sp, #0x20]
add x29, sp, #0x30
mov x19, x0
mov x20, x2
ldr x8, [x0]
ldr x8, [x8, #0x558]
mov x1, x2
blr x8
cmp w0, #0x20
b.ne Lfalse2
ldr x8, [x19]
ldr x8, [x8, #0x640]
mov x0, x19
mov x1, x20
mov w2, #0
mov w3, #0x20
mov x4, sp
blr x8
ldp q0, q1, [sp]
movz x8, #0x1, lsl #16
movk x8, #0x100
ldr q2, [x8]
ldr q3, [x8, #0x20]
eor v0.16b, v0.16b, v2.16b
eor v1.16b, v1.16b, v3.16b
orr v0.16b, v1.16b, v0.16b
ext v1.16b, v0.16b, v0.16b, #8
orr v0.8b, v0.8b, v1.8b
fmov x8, d0
cmp x8, #0
cset w0, eq
b Lend
Lfalse2:
mov w0, #0
Lend:
ldp x19, x20, [sp, #0x20]
ldp x29, x30, [sp, #0x30]
add sp, sp, #0x40
ret
Lfalse1:
mov w0, #0
ret
"""
tail = """
eor v0.16b, v0.16b, v2.16b
eor v1.16b, v1.16b, v3.16b
orr v0.16b, v1.16b, v0.16b
ext v1.16b, v0.16b, v0.16b, #8
orr v0.8b, v0.8b, v1.8b
fmov x8, d0
cmp x8, #0
cset w0, %s
ret
"""
funcs = {
 0x000: src0,
 0x200: "ldp q0, q1, [x0]\nldp q2, q3, [x1]\n" + tail % "ne",                         # ptr vs ptr, !=   -> memcmp(a,b,32) != 0
 0x300: "ldp q0, q1, [x0]\nldp q2, q3, [x1]\nrev64 v2.16b, v2.16b\n" + tail % "eq",   # permuted lanes   -> must NOT become memcmp
 0x400: "ldr q0, [x0]\nldr q1, [x1]\neor v0.16b, v0.16b, v1.16b\next v1.16b, v0.16b, v0.16b, #8\norr v0.8b, v0.8b, v1.8b\nfmov x8, d0\ncmp x8, #0\ncset w0, eq\nret\n",  # 16 bytes
 0x500: "ldp q0, q1, [x0]\nldp q2, q3, [x1]\nstr wzr, [x0]\n" + tail % "eq",          # store between load and compare -> must NOT fire
}
img = bytearray(0x700)
for off, s in funcs.items():
    enc, _ = ks.asm(s, BASE + off); assert len(enc) < (0x100 if off == 0 else 0x100)
    img[off:off + len(enc)] = bytes(enc)
c0 = bytes.fromhex("D10B810A8ACCF9CD05A251779B7FDB9B"); c1 = bytes.fromhex("0D111D23689104EBE68DF37214F2B6CC")
img[0x100:0x110] = c0; img[0x110:0x120] = bytes(range(0xA0, 0xB0)); img[0x120:0x130] = c1; img[0x130:0x140] = bytes(range(0xB0, 0xC0))
open("multi.raw", "wb").write(img); print("wrote multi.raw", len(img))
