#!/bin/sh
# usage: ./run_tests.sh /path/to/decomp_opt_or_dbg /path/to/ghidra-source-root
# The root must contain Ghidra/Processors/AARCH64/data/languages/AARCH64.sla compiled from the PATCHED spec
# (sleigh_opt AARCH64.slaspec AARCH64.sla), and the decompiler must have the raw_loader_hack.patch applied (test harness only).
DEC=${1:?decomp binary}; ROOT=${2:?ghidra root}
HERE=$(cd "$(dirname "$0")" && pwd); cd "$HERE"
python3 make_images.py || exit 1
cat > /tmp/lm_run.cmd <<EOT
load file AARCH64:LE:64:v8A $HERE/multi.raw
adjust vma 0x10000
map function 0x10000 Java_test_v
decompile
print C
map function 0x10200 fn_ptr_ne
decompile
print C
map function 0x10300 fn_permuted
decompile
print C
map function 0x10400 fn_cmp16
decompile
print C
map function 0x10500 fn_store_between
decompile
print C
quit
EOT
SLEIGHHOME=$ROOT "$DEC" < /tmp/lm_run.cmd > /tmp/lm_out.txt 2>&1
python3 check_output.py /tmp/lm_out.txt
