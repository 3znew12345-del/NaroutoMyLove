from keystone import *
BASE=0x10000
DATA=BASE+0x100
src = """
cbz x2, Lfalse1
sub sp, sp, #0x40
stp x29, x30, [sp, #0x30]
stp x19, x20, [sp, #0x20]
add x29, sp, #0x30
mov x19, x0
mov x20, x2
ldr x8, [x0]
ldr x8, [x8, #0x558]
mov x1, x2
blr x8
cmp w0, #0x20
b.ne Lfalse2
ldr x8, [x19]
ldr x8, [x8, #0x640]
mov x0, x19
mov x1, x20
mov w2, #0
mov w3, #0x20
mov x4, sp
blr x8
ldp q0, q1, [sp]
movz x8, #0x1, lsl #16
movk x8, #0x100
ldr q2, [x8]
ldr q3, [x8, #0x20]
eor v0.16b, v0.16b, v2.16b
eor v1.16b, v1.16b, v3.16b
orr v0.16b, v1.16b, v0.16b
ext v1.16b, v0.16b, v0.16b, #8
orr v0.8b, v0.8b, v1.8b
fmov x8, d0
cmp x8, #0
cset w0, eq
b Lend
Lfalse2:
mov w0, #0
Lend:
ldp x19, x20, [sp, #0x20]
ldp x29, x30, [sp, #0x30]
add sp, sp, #0x40
ret
Lfalse1:
mov w0, #0
ret
"""
ks=Ks(KS_ARCH_ARM64,KS_MODE_LITTLE_ENDIAN)
enc,_=ks.asm(src,BASE)
code=bytes(enc)
assert len(code)<0x100,len(code)
c0=bytes.fromhex("D10B810A8ACCF9CD05A251779B7FDB9B")
c1=bytes.fromhex("0D111D23689104EBE68DF37214F2B6CC")
img=bytearray(0x200)
img[:len(code)]=code
img[0x100:0x110]=c0
img[0x110:0x120]=bytes(range(0xA0,0xB0))   # gap (other constant)
img[0x120:0x130]=c1
img[0x130:0x140]=bytes(range(0xB0,0xC0))
open("test.bin","wb").write(img)
print(len(code),"bytes code; func entry",hex(BASE))
import capstone
cs=capstone.Cs(capstone.CS_ARCH_ARM64,capstone.CS_MODE_ARM)
for i in cs.disasm(code,BASE): print(hex(i.address),i.mnemonic,i.op_str)
