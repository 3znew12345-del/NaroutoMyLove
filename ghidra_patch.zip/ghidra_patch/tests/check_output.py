import re, sys
t = open(sys.argv[1]).read()
def body(n):
    m = re.search(r"\n[A-Za-z_0-9 ]+\s+\**%s\(.*?\n}\n" % n, t, re.S); return m.group(0) if m else ""
exp = {  # name: (memcmp calls expected, must contain, must not contain)
 "Java_test_v":      (2, ["builtin_memcmp(axStack_40,&", "axStack_40 + 0x10", "0x10)"], ["CONCAT"]),
 "fn_ptr_ne":        (1, ["builtin_memcmp(param_1,param_2,0x20)", "!= 0"], ["CONCAT"]),
 "fn_cmp16":         (1, ["builtin_memcmp(param_1,param_2,0x10)", "== 0"], ["CONCAT"]),
 "fn_permuted":      (0, [], ["builtin_memcmp"]),
 "fn_store_between": (0, [], ["builtin_memcmp"]),
}
bad = 0
for n, (cnt, must, mustnot) in exp.items():
    b = body(n); ok = b != "" and b.count("builtin_memcmp") == cnt and all(x in b for x in must) and not any(x in b for x in mustnot)
    print(("PASS " if ok else "FAIL ") + n + "  (memcmp calls: %d, expected %d)" % (b.count("builtin_memcmp"), cnt)); bad += (not ok)
sys.exit(1 if bad else 0)
