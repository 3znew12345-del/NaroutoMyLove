#!/usr/bin/env python3
"""Python port of JniRecover.eval() (levels: 0=env(+off), 1=table(+off), 2=fn slot) on a mini p-code IR."""
MAX_DEPTH=32
class V:
    def __init__(s,kind,val=0,slot=None,d=None): s.kind=kind;s.val=val;s.slot=slot;s.d=d   # kind: const|input|uniq
class O:
    def __init__(s,code,ins): s.code=code;s.ins=ins
def const(x): return V('const',x)
def param(slot): return V('input',slot=slot)
def op(code,*ins):
    v=V('uniq'); v.d=O(code,list(ins)); return v
class Sym:
    def __init__(s,level,off,vm,conf): s.level=level;s.off=off;s.vm=vm;s.conf=conf
    def add(s,d): return Sym(s.level,s.off+d,s.vm,s.conf)
    def pen(s,p): return Sym(s.level,s.off,s.vm,max(.5,s.conf-p))
    def same(s,o): return o is not None and (s.level,s.off,s.vm)==(o.level,o.off,o.vm)
def ev(vn,er,vr,path,depth):
    if vn is None or depth>MAX_DEPTH or vn.kind=='const': return None
    if vn.kind=='input':
        if vn.slot in er: return Sym(0,0,False,1.)
        if vn.slot in vr: return Sym(0,0,True,1.)
        return None
    d=vn.d
    if d is None: return None
    c=d.code; i=d.ins
    if c in('COPY','CAST','ZEXT','SEXT'): return ev(i[0],er,vr,path,depth+1)
    if c=='INDIRECT':
        s=ev(i[0],er,vr,path,depth+1); return s.pen(.05) if s else None
    if c=='SUBPIECE':
        if i[1].kind!='const' or i[1].val!=0: return None
        return ev(i[0],er,vr,path,depth+1)
    if c=='ADD':
        a=ev(i[0],er,vr,path,depth+1)
        if a and i[1].kind=='const': return None if a.level==2 else a.add(i[1].val)
        b=ev(i[1],er,vr,path,depth+1)
        if b and i[0].kind=='const': return None if b.level==2 else b.add(i[0].val)
        return None
    if c=='SUB':
        a=ev(i[0],er,vr,path,depth+1)
        if a and i[1].kind=='const' and a.level!=2: return a.add(-i[1].val)
        return None
    if c=='PTRSUB':
        a=ev(i[0],er,vr,path,depth+1)
        if a and i[1].kind=='const' and a.level!=2: return a.add(i[1].val)
        return None
    if c=='PTRADD':
        a=ev(i[0],er,vr,path,depth+1)
        if a and a.level!=2 and i[1].kind=='const' and i[2].kind=='const': return a.add(i[1].val*i[2].val)
        return None
    if c=='LOAD':
        a=ev(i[1],er,vr,path,depth+1)
        if a is None: return None
        if a.level==0 and a.off==0: return Sym(1,0,a.vm,a.conf)
        if a.level==1: return Sym(2,a.off,a.vm,a.conf)
        return None
    if c=='MULTIEQUAL':
        if id(vn) in path: return None
        path.add(id(vn)); res=None; anyv=False
        for x in i:
            if id(x) in path: continue
            s=ev(x,er,vr,path,depth+1)
            if s is None: path.discard(id(vn)); return None
            if anyv and not res.same(s): path.discard(id(vn)); return None
            res = res if (anyv and res.conf<s.conf) else s
            anyv=True
        path.discard(id(vn))
        return res.pen(.05) if anyv else None
    return None
def slot(vn,er={0},vr=set(),ptr=8):
    s=ev(vn,er,vr,set(),0)
    if s is None or s.level!=2: return None
    if s.off<0 or s.off%ptr: return ('BAD',s.off)
    return s.off//ptr, s.vm, round(s.conf,2)
fails=0
def check(n,cond):
    global fails; print(("PASS " if cond else "FAIL ")+n); fails+=(not cond)
env=param(0)
# A: ldr x8,[x0]; ldr x8,[x8,#0x558]  (the user's binary)
check("A  direct  *(*env+0x558) -> slot 171 (GetArrayLength)", slot(op('LOAD',const(1),op('ADD',op('LOAD',const(1),env),const(0x558))))==(171,False,1.0))
check("A2 direct  *(*env+0x640) -> slot 200 (GetByteArrayRegion)", slot(op('LOAD',const(1),op('ADD',op('LOAD',const(1),env),const(0x640))))==(200,False,1.0))
# B: table pointer hoisted, used by two calls through COPY
t=op('COPY',op('LOAD',const(1),env))
check("B  hoisted table ptr, two different slots", slot(op('LOAD',const(1),op('ADD',t,const(0x558))))[0]==171 and slot(op('LOAD',const(1),op('ADD',const(0x640),t)))[0]==200)
# C: env copied through phi (both paths same origin)
p=op('MULTIEQUAL',op('COPY',env),op('COPY',env))
r=slot(op('LOAD',const(1),op('ADD',op('LOAD',const(1),p),const(0x558))))
check("C  MULTIEQUAL agreeing inputs resolves, confidence lowered", r is not None and r[0]==171 and r[2]<1.0)
# D: phi where one input is unrelated -> unresolved
other=param(3)
p=op('MULTIEQUAL',env,other)
check("D  MULTIEQUAL with unrelated input -> unresolved", slot(op('LOAD',const(1),op('ADD',op('LOAD',const(1),p),const(8))))is None)
# D2: phi of two different table offsets -> unresolved
a=op('ADD',op('LOAD',const(1),env),const(8)); b=op('ADD',op('LOAD',const(1),env),const(16))
check("D2 MULTIEQUAL of different slots -> unresolved", slot(op('LOAD',const(1),op('MULTIEQUAL',a,b)))is None)
# E: PTRSUB / PTRADD / SUB / SUBPIECE / ZEXT / INDIRECT shapes
tb=op('LOAD',const(1),env)
check("E1 PTRSUB(table,0x558)", slot(op('LOAD',const(1),op('PTRSUB',tb,const(0x558))))[0]==171)
check("E2 PTRADD(table,171,8)", slot(op('LOAD',const(1),op('PTRADD',tb,const(171),const(8))))[0]==171)
check("E3 SUB(table,-0x558 as neg)", slot(op('LOAD',const(1),op('SUB',op('ADD',tb,const(0x600)),const(0xa8))))[0]==171)
check("E4 SUBPIECE(x,0)+ZEXT wrappers", slot(op('LOAD',const(1),op('ADD',op('ZEXT',op('SUBPIECE',tb,const(0))),const(0x558))))[0]==171)
check("E5 INDIRECT around env (call side effects)", slot(op('LOAD',const(1),op('ADD',op('LOAD',const(1),op('INDIRECT',env)),const(0x558))))[0]==171)
# F: loop-carried phi (env re-assigned to itself in a loop)
phi=V('uniq'); phi.d=O('MULTIEQUAL',[env,phi])
check("F  loop-carried phi (self edge) resolves", slot(op('LOAD',const(1),op('ADD',op('LOAD',const(1),phi),const(0x558))))[0]==171)
# G: negatives
check("G1 load base is unrelated param -> unresolved", slot(op('LOAD',const(1),op('ADD',op('LOAD',const(1),param(2)),const(0x558))))is None)
check("G2 env+8 then deref (not the function table) -> unresolved", slot(op('LOAD',const(1),op('ADD',op('LOAD',const(1),op('ADD',env,const(8))),const(8))))is None)
check("G3 misaligned offset 0x559 flagged, not silently rounded", slot(op('LOAD',const(1),op('ADD',tb,const(0x559))))==('BAD',0x559))
check("G4 three-level deref -> unresolved", slot(op('LOAD',const(1),op('LOAD',const(1),tb)))is None)
check("G5 param not declared as env root -> unresolved", slot(op('LOAD',const(1),op('ADD',op('LOAD',const(1),env),const(0x558))),er={1})is None)
# H: interprocedural: env passed as arg is level0/off0; env+8 is not
check("H1 env passed to callee recognised", (lambda s: s and s.level==0 and s.off==0)(ev(op('COPY',env),{0},set(),set(),0)))
check("H2 env+8 not recognised as env root", not (lambda s: s and s.level==0 and s.off==0)(ev(op('ADD',env,const(8)),{0},set(),set(),0)))
# JavaVM: GetEnv is invoke-interface index 6 -> offset 0x30
vm=param(0)
check("V  JavaVM (*vm)->GetEnv (0x30 -> idx 6) tagged vm", slot(op('LOAD',const(1),op('ADD',op('LOAD',const(1),vm),const(0x30))),er=set(),vr={0})==(6,True,1.0))
print("FAILED:",fails); raise SystemExit(1 if fails else 0)
