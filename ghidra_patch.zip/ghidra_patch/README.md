# Ghidra NEON-idiom + JNI patch  (v3)

## What went wrong in your build run (and what changed)
1. `Marshaling error: Expecting signed integer attribute` on almost every function: the native decompiler was built
   from the uploaded **master** snapshot but run under a **different Ghidra release** (Java side). The two must come from
   the same source tree/tag. -> `apply_patch.py` below works on a release tag and on master.
2. AARCH64 spec failed with `Constraining currently undefined operand imm4` / `Redefining operand`: my EXT constructors were wrong
   (bad `imm4` binding; local names `n`/`m` clashed with token fields). Fixed: pattern is now `imm4 & b_1114=K`, locals are `ext_n`/`ext_m`.
   The fixed spec compiles with sleigh on master and on 12.0.4.
3. The old rule never fired on real code: the real p-code root is `INT_EQUAL(PIECE/OR/XOR tree, 0)` (not a BOOL_AND tree), the
   constants arrive as `SUBPIECE(INT_RIGHT(x,8k),0)`, and pointer loads use a different pointer varnode per 8-byte load.
   The rule now handles all three (found by running the real decompiler, not by modelling).

## Install (same tree/tag as the Ghidra you run)
    python3 apply_patch.py /path/to/ghidra-source-root        # idempotent; use --check to preview
    # then, in <root>/Ghidra/Features/Decompiler/src/decompile/cpp :  make ghidra_opt
    # copy ghidra_opt over <install>/Ghidra/Features/Decompiler/os/linux_x86_64/decompile
    # copy the patched AARCH64neon.sinc into <install>/Ghidra/Processors/AARCH64/data/languages/ and delete AARCH64.sla there
    # (or build the whole tree with gradle and run that build)
Edits: simdidiom.{hh,cc} (new), coreaction.cc (include, group `lanememcmp`, rule in cleanup), userop.{hh,cc} (BUILTIN_MEMCMP),
Makefile, buildNatives.gradle, AARCH64neon.sinc (EXT as plain lane moves). `.orig` backups are written next to each file.
Verified to apply and compile (`g++ -fsyntax-only`) on master and on Ghidra_12.0.4_build; sleigh spec compiles on both.

## Real result (console decompiler on real AArch64 machine code, patched spec + rule)
Your pattern (clone of `Java_cn_rjtool_mobile_G_v`), before: ~80 lines of nested `CONCAT17(... ^ (uint1)((uint8)xRam... >> 0x38) | ...) == 0`. After:

    iVar3 = builtin_memcmp(axStack_40,&xRam0000000000010100,0x10);
    iVar1 = builtin_memcmp(axStack_40 + 0x10,&xRam0000000000010120,0x10);
    bVar2 = iVar3 == 0 && iVar1 == 0;

Two calls of 16, not one of 32: the constants are 0x20 apart (0x4c0 / 0x4e0 in your binary), not one 32-byte object.
`tests/run_tests.sh` re-runs 5 functions (this one, ptr-vs-ptr `!=` -> `memcmp(a,b,0x20) != 0`, 16-byte compare, and two negatives:
permuted lanes via `rev64`, and a `str` between load and compare) and checks the output. Needs `tests/raw_loader_hack.patch`
applied to bfd_arch.cc (test harness only, makes the console tool accept `.raw` files) and `pip install keystone-engine`.

## JniRecover.java (scripts/)
Parses jni.h prototypes -> FunctionDefinitions in JNINativeInterface/JNIInvokeInterface; data-flow resolver for `(*env)->F`;
retypes args/returns (`jstring`, `jbyteArray`, `jclass`, `char*`...); propagates env into callees; EOL comments + bookmarks + JSON;
new: `Java_` name decoding (class/method comment, overload signatures typed), string args of JNI calls shown in the comment,
`RegisterNatives` tables read from memory -> `JNINativeMethod[]` typed, native functions created/renamed/typed from the descriptor.
Tests: `python3 tests/test_parser.py scripts/JniRecover.java <jni.h>` (22 checks), `python3 tests/sim_resolver.py` (20 checks).
NOT run inside Ghidra yet. Not done: typing stack buffers as `jbyte[N]` (the decompiler already shows `xunknown1 axStack_40[32]`).

## Known limits
- Constants in a read-only block that the decompiler folds to constants: comparison becomes `byte == const`, rule does not fire.
- ARM Thumb-tagged function pointers in RegisterNatives are skipped.
- Only AArch64 EXT is lowered; other opaque NEON ops (`rev64`, `tbl`, ...) still block the rule (that is why `fn_permuted` stays raw).
- No run of Ghidra's own decompiler regression suite yet.
