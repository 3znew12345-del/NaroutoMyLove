// JniRecover v2 - JNI recovery pass for Ghidra (post auto-analysis).
//
//  jni.h --parse--> real prototypes --> FunctionDefinitions inside JNINativeInterface / JNIInvokeInterface
//  decompile --> data-flow resolver (CALLIND target = *(*env + slot*ptrSize)) --> JNI member
//  member prototype --> argument/return type propagation (jstring, jbyteArray, jclass, const char*, ...)
//  env/vm pointer propagated interprocedurally into callees that receive it
//  output: types, EOL comments, bookmarks, optional JSON metadata (one record per resolved call site)
//
// Headless:  -postScript JniRecover.java /path/jni.h [/path/out.json]
//@category Android.JNI
import java.io.*;
import java.util.*;
import java.util.regex.*;
import ghidra.app.decompiler.*;
import ghidra.app.script.GhidraScript;
import ghidra.program.model.address.Address;
import ghidra.program.model.data.*;
import ghidra.program.model.listing.*;
import ghidra.program.model.mem.Memory;
import ghidra.program.model.mem.MemoryBlock;
import ghidra.program.model.pcode.*;
import ghidra.program.model.symbol.SourceType;

public class JniRecover extends GhidraScript {
	static final boolean RECOVER_CONSTS = true;   // define byte[N] for undefined read-only data read by the decompiler
	static final int CONST_MIN_SIZE = 16;         // only vector-sized constants (keys, tables), not scalars
	static final int MAX_DEPTH = 32;
	static final CategoryPath CP = new CategoryPath("/JNI");

	// ==== PARSER BEGIN (pure Java, no Ghidra types; unit-tested standalone)
	static final class JniHeader {
		static final class Ty { String base = ""; int stars; String name; }
		static final class Member {
			int index; String name; boolean reserved; boolean varargs;
			Ty ret; List<Ty> params = new ArrayList<>();
		}
		static final Pattern FN = Pattern.compile(
			"^(.*?)\\(\\s*(?:\\w+\\s+)*\\*\\s*(\\w+)\\s*\\)\\s*\\((.*)\\)\\s*(?:\\w+\\s*)*$", Pattern.DOTALL);
		static final Pattern RES = Pattern.compile("^void\\s*\\*\\s*(reserved\\d+)$");
		static final Set<String> SKIP = new HashSet<>(Arrays.asList("const", "struct", "JNICALL", "volatile"));

		static String clean(String s) {
			s = s.replaceAll("(?s)/\\*.*?\\*/", " ").replaceAll("//[^\\n]*", " ");
			StringBuilder sb = new StringBuilder();
			for (String l : s.split("\\n")) if (!l.trim().startsWith("#")) sb.append(l).append('\n');
			return sb.toString();
		}
		static String structBody(String s, String... names) {
			for (String n : names) {
				Matcher m = Pattern.compile("struct\\s+" + n + "\\s*\\{").matcher(s);
				if (!m.find()) continue;
				int i = m.end(), depth = 1;
				while (i < s.length() && depth > 0) {
					char c = s.charAt(i++);
					if (c == '{') depth++; else if (c == '}') depth--;
				}
				return s.substring(m.end(), i - 1);
			}
			return null;
		}
		static Ty parseTy(String raw) {
			Ty t = new Ty();
			List<String> ids = new ArrayList<>();
			Matcher m = Pattern.compile("[A-Za-z_]\\w*|\\*").matcher(raw);
			while (m.find()) {
				String x = m.group();
				if (x.equals("*")) t.stars++;
				else if (!SKIP.contains(x)) ids.add(x);
			}
			if (ids.size() >= 2) t.name = ids.remove(ids.size() - 1);
			t.base = String.join(" ", ids);
			return t;
		}
		static List<Member> parse(String src, String... names) {
			String body = structBody(clean(src), names);
			if (body == null) return null;
			List<Member> out = new ArrayList<>();
			int depth = 0;
			StringBuilder cur = new StringBuilder();
			for (char c : body.toCharArray()) {
				if (c == '(') depth++; else if (c == ')') depth--;
				if (c == ';' && depth == 0) { add(out, cur.toString().replaceAll("\\s+", " ").trim()); cur.setLength(0); }
				else cur.append(c);
			}
			return out;
		}
		static void add(List<Member> out, String d) {
			if (d.isEmpty()) return;
			Member m = new Member();
			m.index = out.size();
			Matcher r = RES.matcher(d);
			if (r.matches()) { m.name = r.group(1); m.reserved = true; out.add(m); return; }
			Matcher f = FN.matcher(d);
			if (!f.matches()) throw new IllegalStateException("cannot parse member: " + d);
			m.ret = parseTy(f.group(1));
			m.name = f.group(2);
			String ps = f.group(3).trim();
			if (!ps.isEmpty() && !ps.equals("void"))
				for (String p : ps.split(",")) {
					p = p.trim();
					if (p.equals("...")) m.varargs = true; else m.params.add(parseTy(p));
				}
			out.add(m);
		}
	}

	// JNI type descriptors and Java_ name mangling (pure Java, unit-tested)
	static final class JniSig {
		static final class Sig { List<String> params = new ArrayList<>(); String ret; }
		static final String PRIM = "ZBCSIJFD";
		static final String[] PRIMT = { "jboolean", "jbyte", "jchar", "jshort", "jint", "jlong", "jfloat", "jdouble" };

		static String refType(String cls) {
			if (cls.equals("java/lang/String")) return "jstring";
			if (cls.equals("java/lang/Class")) return "jclass";
			if (cls.equals("java/lang/Throwable")) return "jthrowable";
			return "jobject";
		}
		// reads one field descriptor at s[pos[0]]; returns JNI type name or null; advances pos
		static String field(String s, int[] pos) {
			if (pos[0] >= s.length()) return null;
			char c = s.charAt(pos[0]++);
			int p = PRIM.indexOf(c);
			if (p >= 0) return PRIMT[p];
			if (c == 'L') {
				int e = s.indexOf(';', pos[0]);
				if (e < 0) return null;
				String cls = s.substring(pos[0], e);
				if (cls.isEmpty()) return null;
				pos[0] = e + 1;
				return refType(cls);
			}
			if (c == '[') {
				if (pos[0] >= s.length()) return null;
				char n = s.charAt(pos[0]);
				int q = PRIM.indexOf(n);
				if (q >= 0) { pos[0]++; return PRIMT[q] + "Array"; }
				String inner = field(s, pos);
				return inner == null ? null : "jobjectArray";
			}
			return null;
		}
		static List<String> params(String s) {         // descriptor without parentheses
			List<String> out = new ArrayList<>();
			int[] pos = { 0 };
			while (pos[0] < s.length()) {
				String t = field(s, pos);
				if (t == null) return null;
				out.add(t);
			}
			return out;
		}
		static Sig parse(String d) {                   // "(Ljava/lang/String;[BI)Z"
			if (d == null || d.length() < 3 || d.charAt(0) != '(') return null;
			int close = d.indexOf(')');
			if (close < 0) return null;
			Sig sg = new Sig();
			sg.params = params(d.substring(1, close));
			if (sg.params == null) return null;
			String r = d.substring(close + 1);
			if (r.equals("V")) sg.ret = "void";
			else { int[] pos = { 0 }; sg.ret = field(r, pos); if (sg.ret == null || pos[0] != r.length()) return null; }
			return sg;
		}
	}
	static final class JniName {
		String cls, method; List<String> sigParams;    // sigParams != null for overloaded natives
		// Java_pkg_Cls_meth  |  Java_pkg_Cls_meth__Ljava_lang_String_2I   (JNI short/long names)
		static JniName parse(String n) {
			if (n == null || !n.startsWith("Java_") || n.length() < 8) return null;
			List<String> parts = new ArrayList<>();
			StringBuilder cur = new StringBuilder();
			String sig = null;
			for (int i = 5; i < n.length(); i++) {
				char c = n.charAt(i);
				if (c != '_') { cur.append(c); continue; }
				char x = i + 1 < n.length() ? n.charAt(i + 1) : 0;
				if (x == '1') { cur.append('_'); i++; }
				else if (x == '2') { cur.append(';'); i++; }
				else if (x == '3') { cur.append('['); i++; }
				else if (x == '0' && i + 5 < n.length() + 0 && n.substring(i + 2, i + 6).matches("[0-9a-fA-F]{4}")) {
					cur.append((char) Integer.parseInt(n.substring(i + 2, i + 6), 16)); i += 5;
				}
				else if (x == '_') { sig = decodeSig(n.substring(i + 2)); parts.add(cur.toString()); cur.setLength(0); break; }
				else { parts.add(cur.toString()); cur.setLength(0); }
			}
			if (sig == null) parts.add(cur.toString());
			else if (cur.length() > 0) parts.add(cur.toString());
			if (parts.size() < 2) return null;
			for (String p : parts) if (p.isEmpty()) return null;
			JniName r = new JniName();
			r.method = parts.get(parts.size() - 1);
			r.cls = String.join(".", parts.subList(0, parts.size() - 1));
			if (sig != null) { r.sigParams = JniSig.params(sig); if (r.sigParams == null) return null; }
			return r;
		}
		static String decodeSig(String m) {            // mangled arg signature -> "Ljava/lang/String;I"
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < m.length(); i++) {
				char c = m.charAt(i);
				if (c != '_') { sb.append(c); continue; }
				char x = i + 1 < m.length() ? m.charAt(i + 1) : 0;
				if (x == '1') { sb.append('_'); i++; }
				else if (x == '2') { sb.append(';'); i++; }
				else if (x == '3') { sb.append('['); i++; }
				else if (x == '0' && i + 5 < m.length() + 0 && m.substring(i + 2, i + 6).matches("[0-9a-fA-F]{4}")) {
					sb.append((char) Integer.parseInt(m.substring(i + 2, i + 6), 16)); i += 5;
				}
				else sb.append('/');
			}
			return sb.toString();
		}
	}
	// ==== PARSER END

	// ---- state
	DataTypeManager dtm;
	int ptrSize;
	List<JniHeader.Member> envMembers, vmMembers;
	Map<String, DataType> named = new HashMap<>();
	Map<String, Integer> rank = new HashMap<>();
	Map<JniHeader.Member, DataType[]> protos = new HashMap<>();
	Set<String> unknownTypes = new TreeSet<>();
	DataType envT, vmT, jobjectT;
	Map<Function, Set<Integer>> envRoots = new LinkedHashMap<>();
	Map<Function, Set<Integer>> vmRoots = new LinkedHashMap<>();
	Set<Function> done = new HashSet<>();
	List<String> json = new ArrayList<>();
	List<String> natives = new ArrayList<>();
	Map<PcodeOp, JniHeader.Member> resolvedOps = new HashMap<>();
	Map<PcodeOp, List<String>> strArgs = new HashMap<>();
	int nNatives;
	int nResolved, nUnresolved, nRetyped;

	// ---- symbolic value of a pointer expression:  level 0 = env (+off), 1 = *env i.e. table (+off), 2 = fn slot read at off
	static final class Sym {
		final int level; final long off; final boolean vm; final float conf;
		Sym(int level, long off, boolean vm, float conf) { this.level = level; this.off = off; this.vm = vm; this.conf = conf; }
		Sym add(long d) { return new Sym(level, off + d, vm, conf); }
		Sym pen(float p) { return new Sym(level, off, vm, Math.max(0.5f, conf - p)); }
		boolean same(Sym o) { return o != null && level == o.level && off == o.off && vm == o.vm; }
	}

	@Override
	protected void run() throws Exception {
		dtm = currentProgram.getDataTypeManager();
		ptrSize = currentProgram.getDefaultPointerSize();
		String[] args = getScriptArgs();
		File jni = args.length > 0 ? new File(args[0])
				: askFile("Select jni.h (NDK: <ndk>/toolchains/llvm/prebuilt/*/sysroot/usr/include/jni.h)", "Use");
		String src = new String(java.nio.file.Files.readAllBytes(jni.toPath()), "UTF-8");
		envMembers = JniHeader.parse(src, "JNINativeInterface_", "JNINativeInterface");
		vmMembers = JniHeader.parse(src, "JNIInvokeInterface_", "JNIInvokeInterface");
		if (envMembers == null || envMembers.size() < 200)
			throw new IllegalStateException("JNINativeInterface not found / too small in " + jni);
		println("jni.h: " + envMembers.size() + " JNIEnv slots, " + (vmMembers == null ? 0 : vmMembers.size()) + " JavaVM slots");
		buildTypes();
		if (!unknownTypes.isEmpty()) println("WARNING unknown types in jni.h mapped to void*: " + unknownTypes);

		for (Function f : currentProgram.getFunctionManager().getFunctions(true)) {
			String n = f.getName();
			if (n.startsWith("Java_")) root(f, 0, false);
			else if (n.equals("JNI_OnLoad") || n.equals("JNI_OnUnload")) root(f, 0, true);
		}
		Function cur = currentAddress == null ? null : getFunctionContaining(currentAddress);
		if (cur != null && !envRoots.containsKey(cur) && !vmRoots.containsKey(cur) && cur.getParameterCount() > 0
				&& askYesNo("JniRecover", "Treat parameter 0 of " + cur.getName() + " as JNIEnv*?"))
			root(cur, 0, false);

		DecompInterface ifc = new DecompInterface();
		ifc.openProgram(currentProgram);
		int guard = 0;
		while (guard++ < 5000) {
			Function next = null;
			for (Function f : envRoots.keySet()) if (!done.contains(f)) { next = f; break; }
			if (next == null) for (Function f : vmRoots.keySet()) if (!done.contains(f)) { next = f; break; }
			if (next == null) break;
			done.add(next);
			monitor.checkCancelled();
			try { process(ifc, next); }
			catch (Exception e) { println("ERROR " + next.getName() + ": " + e); }
		}
		println(String.format("JniRecover: %d JNI calls resolved, %d CALLIND unresolved, %d variables retyped, %d registered natives, %d functions",
			nResolved, nUnresolved, nRetyped, nNatives, done.size()));
		exportJson(args);
	}

	// ================= types =================
	static final String[] REFS = { "jobject", "jclass", "jthrowable", "jstring", "jarray", "jbooleanArray", "jbyteArray",
		"jcharArray", "jshortArray", "jintArray", "jlongArray", "jfloatArray", "jdoubleArray", "jobjectArray", "jweak",
		"jmethodID", "jfieldID" };

	DataType def(String name, DataType dt) {
		DataType r = dtm.resolve(new TypedefDataType(CP, name, dt), DataTypeConflictHandler.REPLACE_HANDLER);
		named.put(name, r);
		return r;
	}
	DataType ptr(DataType dt) { return new PointerDataType(dt, ptrSize, dtm); }

	void buildTypes() throws Exception {
		DataType vp = ptr(VoidDataType.dataType);
		def("jboolean", UnsignedCharDataType.dataType);
		def("jbyte", SignedByteDataType.dataType);
		def("jchar", UnsignedShortDataType.dataType);
		def("jshort", ShortDataType.dataType);
		def("jint", IntegerDataType.dataType);
		def("jlong", LongLongDataType.dataType);
		def("jfloat", FloatDataType.dataType);
		def("jdouble", DoubleDataType.dataType);
		def("jsize", named.get("jint"));
		def("jobjectRefType", IntegerDataType.dataType);
		def("va_list", vp);
		for (String r : REFS) def(r, vp);
		jobjectT = named.get("jobject");
		for (String r : REFS) rank.put(r, 3);
		rank.put("jobject", 1); rank.put("jweak", 1); rank.put("jarray", 2); rank.put("jobjectArray", 3);

		UnionDataType u = new UnionDataType(CP, "jvalue");
		for (String[] m : new String[][] { { "jboolean", "z" }, { "jbyte", "b" }, { "jchar", "c" }, { "jshort", "s" },
				{ "jint", "i" }, { "jlong", "j" }, { "jfloat", "f" }, { "jdouble", "d" }, { "jobject", "l" } })
			u.add(named.get(m[0]), m[1], null);
		named.put("jvalue", dtm.resolve(u, DataTypeConflictHandler.REPLACE_HANDLER));

		DataType cp = ptr(CharDataType.dataType);
		StructureDataType nm = new StructureDataType(CP, "JNINativeMethod", 0);
		nm.add(cp, ptrSize, "name", null);
		nm.add(cp, ptrSize, "signature", null);
		nm.add(vp, ptrSize, "fnPtr", null);
		named.put("JNINativeMethod", dtm.resolve(nm, DataTypeConflictHandler.REPLACE_HANDLER));

		Structure ni = (Structure) dtm.resolve(new StructureDataType(CP, "JNINativeInterface", 0), DataTypeConflictHandler.REPLACE_HANDLER);
		Structure vi = (Structure) dtm.resolve(new StructureDataType(CP, "JNIInvokeInterface", 0), DataTypeConflictHandler.REPLACE_HANDLER);
		named.put("JNIEnv", def("JNIEnv", ptr(ni)));
		named.put("JavaVM", def("JavaVM", ptr(vi)));
		envT = ptr(named.get("JNIEnv"));
		vmT = ptr(named.get("JavaVM"));
		fill(ni, envMembers, vp);
		if (vmMembers != null) fill(vi, vmMembers, vp);
	}

	void fill(Structure st, List<JniHeader.Member> ms, DataType vp) throws Exception {
		st.deleteAll();
		for (JniHeader.Member m : ms) {
			DataType mt = vp;
			if (!m.reserved) {
				FunctionDefinitionDataType fd = new FunctionDefinitionDataType(CP, m.name, dtm);
				fd.setReturnType(toDT(m.ret));
				DataType[] pt = new DataType[m.params.size()];
				ParameterDefinition[] pd = new ParameterDefinition[pt.length];
				for (int i = 0; i < pt.length; i++) {
					pt[i] = toDT(m.params.get(i));
					String pn = m.params.get(i).name;
					pd[i] = new ParameterDefinitionImpl(pn != null ? pn : "a" + i, pt[i], null);
				}
				fd.setArguments(pd);
				fd.setVarArgs(m.varargs);
				mt = ptr(dtm.resolve(fd, DataTypeConflictHandler.REPLACE_HANDLER));
				protos.put(m, pt);
			}
			st.add(mt, ptrSize, m.name, null);
		}
	}

	DataType toDT(JniHeader.Ty t) {
		DataType b;
		String n = t.base;
		if (named.containsKey(n)) b = named.get(n);
		else if (n.equals("void")) b = VoidDataType.dataType;
		else if (n.equals("char")) b = CharDataType.dataType;
		else if (n.equals("int")) b = IntegerDataType.dataType;
		else { unknownTypes.add(n); b = VoidDataType.dataType; if (t.stars == 0) b = ptr(b); }
		for (int i = 0; i < t.stars; i++) b = ptr(b);
		return b;
	}

	// ================= driver =================
	void root(Function f, int slot, boolean vm) {
		if (f.getParameterCount() <= slot) return;
		(vm ? vmRoots : envRoots).computeIfAbsent(f, k -> new TreeSet<>()).add(slot);
		try {
			Parameter p = f.getParameter(slot);
			p.setDataType(vm ? vmT : envT, SourceType.USER_DEFINED);
			if (p.getSource() == SourceType.DEFAULT) p.setName(vm ? "vm" : "env", SourceType.USER_DEFINED);
			if (f.getName().startsWith("Java_") && slot == 0 && f.getParameterCount() > 1) {
				Parameter q = f.getParameter(1);
				if (generic(q.getDataType())) q.setDataType(jobjectT, SourceType.USER_DEFINED);
				if (q.getSource() == SourceType.DEFAULT) q.setName("thiz", SourceType.USER_DEFINED);
				javaName(f);
			}
		}
		catch (Exception e) { println("root " + f.getName() + ": " + e.getMessage()); }
	}

	void javaName(Function f) {
		JniName jn = JniName.parse(f.getName());
		if (jn == null) return;
		try { f.setComment("Java: " + jn.cls + "." + jn.method + (jn.sigParams != null ? " (overload)" : "")); } catch (Exception e) { }
		if (jn.sigParams == null) return;
		for (int i = 0; i < jn.sigParams.size() && 2 + i < f.getParameterCount(); i++) {
			DataType dt = named.get(jn.sigParams.get(i));
			Parameter p = f.getParameter(2 + i);
			try {
				if (dt != null && (generic(p.getDataType()) || rankOf(p.getDataType()) < rank.getOrDefault(jn.sigParams.get(i), 0)))
					p.setDataType(dt, SourceType.USER_DEFINED);
			}
			catch (Exception e) { println("sig type " + f.getName() + "[" + (2 + i) + "]: " + e.getMessage()); }
		}
	}

	boolean generic(DataType t) {
		if (t == null || Undefined.isUndefined(t)) return true;
		DataType b = ghidra.program.database.data.DataTypeUtilities.getBaseDataType(t);
		if (b instanceof AbstractIntegerDataType && t.getLength() == ptrSize) return true;
		if (b instanceof Pointer) {
			DataType e = ((Pointer) b).getDataType();
			return e == null || Undefined.isUndefined(e) || e instanceof VoidDataType || e instanceof AbstractIntegerDataType;
		}
		return false;
	}
	int rankOf(DataType t) { return t == null ? 0 : rank.getOrDefault(t.getName(), 0); }

	static final class Pick { HighSymbol sym; DataType dt; int rank; boolean conflict; String why; }

	void process(DecompInterface ifc, Function f) throws Exception {
		DecompileResults r = ifc.decompileFunction(f, 60, monitor);
		if (r == null || !r.decompileCompleted()) { println("skip " + f.getName() + ": " + (r == null ? "null" : r.getErrorMessage())); return; }
		HighFunction hf = r.getHighFunction();
		Set<Integer> er = envRoots.getOrDefault(f, Collections.emptySet());
		Set<Integer> vr = vmRoots.getOrDefault(f, Collections.emptySet());
		resolvedOps.clear();
		strArgs.clear();
		Map<HighSymbol, Pick> picks = new LinkedHashMap<>();
		List<PcodeOpAST> ops = new ArrayList<>();
		Iterator<PcodeOpAST> it = hf.getPcodeOps();
		while (it.hasNext()) ops.add(it.next());

		for (PcodeOpAST op : ops) {
			if (op.getOpcode() == PcodeOp.CALLIND) callInd(f, op, er, vr, picks);
			else if (op.getOpcode() == PcodeOp.CALL) propagateRoot(f, op, er, vr);
		}
		for (PcodeOpAST op : ops)
			if (op.getOpcode() == PcodeOp.CALLIND && resolvedOps.containsKey(op) && resolvedOps.get(op).name.equals("RegisterNatives"))
				registerNatives(f, op);
		for (Pick p : picks.values()) {
			if (p.conflict) { println(f.getName() + ": conflicting JNI types for " + p.sym.getName() + " (" + p.why + "), left as is"); continue; }
			DataType cur = p.sym.getDataType();
			if (!(generic(cur) || (rankOf(cur) > 0 && rankOf(cur) < p.rank))) continue;
			if (cur != null && cur.getName().equals(p.dt.getName())) continue;
			try { applyType(p.sym, p.dt); nRetyped++; }
			catch (Exception e) { println(f.getName() + ": retype " + p.sym.getName() + " -> " + p.dt.getName() + " failed: " + e.getMessage()); }
		}
		if (f.getName().startsWith("Java_") && f.getParameterCount() > 1 && er.contains(0)) {
			Parameter q = f.getParameter(1);
			if (q.getDataType().getName().equals("jclass") && q.getName().equals("thiz"))
				try { q.setName("clazz", SourceType.USER_DEFINED); } catch (Exception e) { }
		}
		if (RECOVER_CONSTS) for (PcodeOpAST op : ops) for (int i = 0; i < op.getNumInputs(); i++) defineConst(op.getInput(i));
	}

	void applyType(HighSymbol sym, DataType dt) throws Exception {
		if (sym.isParameter()) {
			Function f = sym.getHighFunction().getFunction();
			f.getParameter(sym.getCategoryIndex()).setDataType(dt, SourceType.USER_DEFINED);
		}
		else HighFunctionDBUtil.updateDBVariable(sym, null, dt, SourceType.USER_DEFINED);
	}

	// ================= call sites =================
	void callInd(Function f, PcodeOpAST op, Set<Integer> er, Set<Integer> vr, Map<HighSymbol, Pick> picks) {
		Sym s = eval(op.getInput(0), er, vr, new HashSet<>(), 0);
		if (s == null || s.level != 2) { nUnresolved++; return; }
		List<JniHeader.Member> tbl = s.vm ? vmMembers : envMembers;
		if (tbl == null || s.off < 0 || s.off % ptrSize != 0 || s.off / ptrSize >= tbl.size()) {
			println(f.getName() + ": JNI slot offset 0x" + Long.toHexString(s.off) + " outside table at " + op.getSeqnum().getTarget());
			nUnresolved++;
			return;
		}
		JniHeader.Member m = tbl.get((int) (s.off / ptrSize));
		if (m.reserved) { nUnresolved++; return; }
		nResolved++;
		Address at = op.getSeqnum().getTarget();
		resolvedOps.put(op, m);
		List<String> ss = new ArrayList<>();
		for (int i = 1; i < m.params.size() && 1 + i < op.getNumInputs(); i++) {
			JniHeader.Ty t = m.params.get(i);
			if (t.base.equals("char") && t.stars == 1) { String str = readStr(constAddr(op.getInput(1 + i), 0)); if (str != null) ss.add(str); }
		}
		strArgs.put(op, ss);
		StringBuilder txt = new StringBuilder((s.vm ? "JavaVM::" : "JNIEnv::") + m.name);
		if (!ss.isEmpty()) { txt.append('('); for (int i = 0; i < ss.size(); i++) txt.append(i > 0 ? ", " : "").append('"').append(ss.get(i)).append('"'); txt.append(')'); }
		annotate(at, txt.toString());
		StringBuilder sj = new StringBuilder();
		for (int i = 0; i < ss.size(); i++) sj.append(i > 0 ? "," : "").append('"').append(esc(ss.get(i))).append('"');
		json.add(String.format("{\"function\":\"%s\",\"addr\":\"%s\",\"iface\":\"%s\",\"member\":\"%s\",\"slot\":%d,\"offset\":%d,\"confidence\":%.2f,\"strings\":[%s]}",
			esc(f.getName()), at, s.vm ? "JavaVM" : "JNIEnv", m.name, m.index, s.off, s.conf, sj));
		DataType[] pt = protos.get(m);
		for (int i = 1; i < m.params.size() && 1 + i < op.getNumInputs(); i++) {
			JniHeader.Ty t = m.params.get(i);
			if (t.stars == 0 && !rank.containsKey(t.base)) continue;      // jint/jsize/...: nothing to learn
			pick(picks, op.getInput(1 + i), pt[i], t.stars > 0 ? 3 : rank.get(t.base), m.name + " arg " + i);
		}
		JniHeader.Ty rt = m.ret;
		if (op.getOutput() != null && (rt.stars > 0 || rank.containsKey(rt.base)))
			pick(picks, op.getOutput(), toDT(rt), rt.stars > 0 ? 3 : rank.get(rt.base), m.name + " return");
	}

	void pick(Map<HighSymbol, Pick> picks, Varnode v, DataType dt, int rk, String why) {
		if (v == null || dt == null || v.isConstant()) return;
		HighVariable hv = v.getHigh();
		if (hv == null || hv.getSymbol() == null) return;
		HighSymbol sym = hv.getSymbol();
		Pick old = picks.get(sym);
		if (old == null) { Pick p = new Pick(); p.sym = sym; p.dt = dt; p.rank = rk; p.why = why; picks.put(sym, p); return; }
		if (rk > old.rank) { old.dt = dt; old.rank = rk; old.conflict = false; old.why = why; }
		else if (rk == old.rank && !old.dt.getName().equals(dt.getName())) { old.conflict = true; old.why = old.why + " vs " + why; }
	}

	// env/vm passed to a direct callee -> callee param is a root too
	void propagateRoot(Function f, PcodeOpAST op, Set<Integer> er, Set<Integer> vr) {
		Address ta = op.getInput(0).getAddress();
		Function g = currentProgram.getFunctionManager().getFunctionAt(ta);
		if (g == null || g.isExternal()) return;
		if (g.isThunk()) { Function t = g.getThunkedFunction(true); if (t != null) g = t; }
		for (int i = 1; i < op.getNumInputs(); i++) {
			Sym s = eval(op.getInput(i), er, vr, new HashSet<>(), 0);
			if (s == null || s.level != 0 || s.off != 0 || g.getParameterCount() < i) continue;
			boolean known = (s.vm ? vmRoots : envRoots).getOrDefault(g, Collections.emptySet()).contains(i - 1);
			if (!known) { root(g, i - 1, s.vm); println(f.getName() + " -> " + g.getName() + ": " + (s.vm ? "JavaVM*" : "JNIEnv*") + " passed as arg " + (i - 1)); }
		}
	}

	// ================= data-flow resolver =================
	Sym eval(Varnode vn, Set<Integer> er, Set<Integer> vr, Set<Varnode> path, int depth) {
		if (vn == null || depth > MAX_DEPTH || vn.isConstant()) return null;
		if (vn.isInput()) {
			HighVariable hv = vn.getHigh();
			if (hv instanceof HighParam) {
				int slot = ((HighParam) hv).getSlot();
				if (er.contains(slot)) return new Sym(0, 0, false, 1f);
				if (vr.contains(slot)) return new Sym(0, 0, true, 1f);
			}
			return null;
		}
		PcodeOp d = vn.getDef();
		if (d == null) return null;
		switch (d.getOpcode()) {
			case PcodeOp.COPY:
			case PcodeOp.CAST:
			case PcodeOp.INT_ZEXT:
			case PcodeOp.INT_SEXT:
				return eval(d.getInput(0), er, vr, path, depth + 1);
			case PcodeOp.INDIRECT: {
				Sym s = eval(d.getInput(0), er, vr, path, depth + 1);
				return s == null ? null : s.pen(0.05f);
			}
			case PcodeOp.SUBPIECE:
				if (!d.getInput(1).isConstant() || d.getInput(1).getOffset() != 0) return null;
				return eval(d.getInput(0), er, vr, path, depth + 1);
			case PcodeOp.INT_ADD: {
				Sym a = eval(d.getInput(0), er, vr, path, depth + 1);
				if (a != null && d.getInput(1).isConstant()) return a.level == 2 ? null : a.add(d.getInput(1).getOffset());
				Sym b = eval(d.getInput(1), er, vr, path, depth + 1);
				if (b != null && d.getInput(0).isConstant()) return b.level == 2 ? null : b.add(d.getInput(0).getOffset());
				return null;
			}
			case PcodeOp.INT_SUB: {
				Sym a = eval(d.getInput(0), er, vr, path, depth + 1);
				if (a != null && d.getInput(1).isConstant() && a.level != 2) return a.add(-d.getInput(1).getOffset());
				return null;
			}
			case PcodeOp.PTRSUB: {
				Sym a = eval(d.getInput(0), er, vr, path, depth + 1);
				if (a != null && d.getInput(1).isConstant() && a.level != 2) return a.add(d.getInput(1).getOffset());
				return null;
			}
			case PcodeOp.PTRADD: {
				Sym a = eval(d.getInput(0), er, vr, path, depth + 1);
				if (a != null && a.level != 2 && d.getInput(1).isConstant() && d.getInput(2).isConstant())
					return a.add(d.getInput(1).getOffset() * d.getInput(2).getOffset());
				return null;
			}
			case PcodeOp.LOAD: {
				Sym a = eval(d.getInput(1), er, vr, path, depth + 1);
				if (a == null) return null;
				if (a.level == 0 && a.off == 0) return new Sym(1, 0, a.vm, a.conf);
				if (a.level == 1) return new Sym(2, a.off, a.vm, a.conf);
				return null;
			}
			case PcodeOp.MULTIEQUAL: {
				if (!path.add(vn)) return null;              // loop-carried edge: ignore, other inputs decide
				Sym res = null;
				boolean any = false;
				for (int i = 0; i < d.getNumInputs(); i++) {
					Varnode in = d.getInput(i);
					if (path.contains(in)) continue;
					Sym s = eval(in, er, vr, path, depth + 1);
					if (s == null) { path.remove(vn); return null; }
					if (any && !res.same(s)) { path.remove(vn); return null; }
					res = any && res.conf < s.conf ? res : s;
					any = true;
				}
				path.remove(vn);
				return any ? res.pen(0.05f) : null;
			}
			default:
				return null;
		}
	}

	// ================= constants / strings / RegisterNatives =================
	Address constAddr(Varnode v, int depth) {
		if (v == null || depth > 8) return null;
		if (v.isConstant()) {
			long off = v.getOffset();
			if (off == 0) return null;
			try {
				Address a = toAddr(off);
				return a != null && currentProgram.getMemory().contains(a) ? a : null;
			}
			catch (Exception e) { return null; }
		}
		PcodeOp d = v.getDef();
		if (d == null) return null;
		if (d.getOpcode() == PcodeOp.COPY || d.getOpcode() == PcodeOp.CAST) return constAddr(d.getInput(0), depth + 1);
		return null;
	}

	String readStr(Address a) {
		if (a == null) return null;
		try {
			Memory mem = currentProgram.getMemory();
			StringBuilder sb = new StringBuilder();
			for (int i = 0; i < 512; i++) {
				int b = mem.getByte(a.add(i)) & 0xff;
				if (b == 0) return sb.length() > 0 ? sb.toString() : null;
				if ((b < 0x20 && b != 9 && b != 10) || b > 0x7e) return null;   // JNI names/signatures/messages: ASCII
				sb.append((char) b);
			}
		}
		catch (Exception e) { /* unreadable */ }
		return null;
	}

	long readPtr(Memory mem, Address a) throws Exception {
		return ptrSize == 8 ? mem.getLong(a) : (mem.getInt(a) & 0xffffffffL);
	}

	// class name from a jclass value produced by FindClass("...") in the same function
	String className(Varnode v, int depth) {
		if (v == null || depth > 8) return null;
		PcodeOp d = v.getDef();
		if (d == null) return null;
		switch (d.getOpcode()) {
			case PcodeOp.COPY:
			case PcodeOp.CAST:
			case PcodeOp.INDIRECT:
				return className(d.getInput(0), depth + 1);
			case PcodeOp.MULTIEQUAL: {
				String r = null;
				for (int i = 0; i < d.getNumInputs(); i++) {
					String s = className(d.getInput(i), depth + 1);
					if (s == null || (r != null && !r.equals(s))) return null;
					r = s;
				}
				return r;
			}
			case PcodeOp.CALLIND: {
				JniHeader.Member m = resolvedOps.get(d);
				List<String> ss = strArgs.get(d);
				if (m != null && m.name.equals("FindClass") && ss != null && !ss.isEmpty()) return ss.get(0);
				return null;
			}
			default:
				return null;
		}
	}

	void registerNatives(Function f, PcodeOp op) {
		if (op.getNumInputs() < 5) return;
		Address at = op.getSeqnum().getTarget();
		Address tbl = constAddr(op.getInput(3), 0);
		if (tbl == null) { println(f.getName() + ": RegisterNatives table is not a constant address at " + at + " (built at runtime?)"); return; }
		Varnode nv = op.getInput(4);
		int n = nv.isConstant() ? (int) nv.getOffset() : -1;
		if (n == 0 || n > 4096) return;
		String cls = className(op.getInput(2), 0);
		Memory mem = currentProgram.getMemory();
		int es = 3 * ptrSize, found = 0;
		for (int i = 0; n < 0 ? i < 256 : i < n; i++) {
			try {
				Address e = tbl.add((long) i * es);
				String nm = readStr(toAddr(readPtr(mem, e)));
				String sg = readStr(toAddr(readPtr(mem, e.add(ptrSize))));
				long fp = readPtr(mem, e.add(2L * ptrSize));
				if (nm == null || sg == null) { if (n < 0) break; continue; }
				JniSig.Sig sig = JniSig.parse(sg);
				Address fa = toAddr(fp);
				found++;
				nNatives++;
				natives.add(String.format("{\"class\":%s,\"name\":\"%s\",\"sig\":\"%s\",\"fn\":\"%s\",\"table\":\"%s\"}",
					cls == null ? "null" : "\"" + esc(cls) + "\"", esc(nm), esc(sg), fa, tbl));
				if (fa != null && mem.contains(fa)) bindNative(fa, cls, nm, sig);
			}
			catch (Exception ex) { println("RegisterNatives entry " + i + " at " + tbl + ": " + ex.getMessage()); break; }
		}
		if (found > 0) {
			try {
				DataUtilities.createData(currentProgram, tbl, new ArrayDataType(named.get("JNINativeMethod"), found, 3 * ptrSize), -1, false,
					DataUtilities.ClearDataMode.CLEAR_ALL_UNDEFINED_CONFLICT_DATA);
				currentProgram.getSymbolTable().createLabel(tbl, String.format("JNINativeMethods_%x", tbl.getOffset()), SourceType.ANALYSIS);
			}
			catch (Exception e) { /* table already typed */ }
			println(f.getName() + ": RegisterNatives -> " + found + " native methods" + (cls != null ? " of " + cls : ""));
		}
	}

	void bindNative(Address fa, String cls, String name, JniSig.Sig sig) throws Exception {
		if ((fa.getOffset() & 1) != 0 && ptrSize == 4) { println("skip Thumb-tagged native " + name + " @ " + fa); return; }
		Function g = currentProgram.getFunctionManager().getFunctionAt(fa);
		if (g == null) {
			disassemble(fa);
			g = createFunction(fa, null);
			if (g == null) { println("cannot create function for native " + name + " @ " + fa); return; }
		}
		if (g.getSymbol().getSource() == SourceType.DEFAULT) {
			String nn = "nat_" + (cls == null ? "" : cls.replace('/', '_').replace('.', '_') + "_") + name;
			try { g.setName(nn, SourceType.USER_DEFINED); }
			catch (Exception e) { try { g.setName(nn + "_" + fa, SourceType.USER_DEFINED); } catch (Exception e2) { } }
		}
		try { g.setComment("RegisterNatives: " + (cls == null ? "?" : cls) + "." + name + (sig == null ? "" : "")); } catch (Exception e) { }
		if (sig != null) {
			List<Variable> ps = new ArrayList<>();
			ps.add(new ParameterImpl("env", envT, currentProgram));
			ps.add(new ParameterImpl("thiz", jobjectT, currentProgram));
			for (int i = 0; i < sig.params.size(); i++) {
				DataType dt = named.get(sig.params.get(i));
				ps.add(new ParameterImpl("a" + i, dt == null ? jobjectT : dt, currentProgram));
			}
			DataType rt = sig.ret.equals("void") ? VoidDataType.dataType : named.get(sig.ret);
			g.updateFunction(null, new ReturnParameterImpl(rt == null ? jobjectT : rt, currentProgram), ps,
				Function.FunctionUpdateType.DYNAMIC_STORAGE_FORMAL_PARAMS, true, SourceType.USER_DEFINED);
		}
		envRoots.computeIfAbsent(g, k -> new TreeSet<>()).add(0);      // decompile it too: its own JNI calls get resolved
	}

	// ================= listing metadata =================
	void annotate(Address at, String text) {
		try {
			Listing l = currentProgram.getListing();
			String old = l.getComment(CodeUnit.EOL_COMMENT, at);
			String nt = "JNI: " + text;
			if (old == null || old.isEmpty()) l.setComment(at, CodeUnit.EOL_COMMENT, nt);
			else if (!old.contains("JNI: ")) l.setComment(at, CodeUnit.EOL_COMMENT, old + " | " + nt);
			currentProgram.getBookmarkManager().setBookmark(at, BookmarkType.INFO, "JNI", text);
		}
		catch (Exception e) { /* comments are best-effort */ }
	}

	void defineConst(Varnode vn) {
		if (vn == null || !vn.isAddress() || vn.getSize() < CONST_MIN_SIZE) return;
		Address ad = vn.getAddress();
		if (!ad.getAddressSpace().isMemorySpace()) return;
		MemoryBlock blk = currentProgram.getMemory().getBlock(ad);
		if (blk == null || !blk.isInitialized() || blk.isExecute() || blk.isWrite()) return;
		if (currentProgram.getListing().getDefinedDataAt(ad) != null) return;
		try {
			DataUtilities.createData(currentProgram, ad, new ArrayDataType(ByteDataType.dataType, vn.getSize(), 1), -1, false,
				DataUtilities.ClearDataMode.CLEAR_ALL_UNDEFINED_CONFLICT_DATA);
			currentProgram.getSymbolTable().createLabel(ad, String.format("K_%x", ad.getOffset()), SourceType.ANALYSIS);
		}
		catch (Exception e) { /* overlapping data: leave as is */ }
	}

	static String esc(String s) { return s.replace("\\", "\\\\").replace("\"", "\\\""); }

	void exportJson(String[] args) throws Exception {
		File out = null;
		if (args.length > 1) out = new File(args[1]);
		else if (!isRunningHeadless() && !json.isEmpty() && askYesNo("JniRecover", "Export " + json.size() + " JNI call records as JSON?"))
			out = askFile("Save JSON metadata", "Save");
		if (out == null) return;
		try (PrintWriter w = new PrintWriter(out, "UTF-8")) {
			w.println("{\"program\":\"" + esc(currentProgram.getName()) + "\",\"ptrSize\":" + ptrSize + ",\"calls\":[");
			for (int i = 0; i < json.size(); i++) w.println("  " + json.get(i) + (i + 1 < json.size() ? "," : ""));
			w.println("],\"natives\":[");
			for (int i = 0; i < natives.size(); i++) w.println("  " + natives.get(i) + (i + 1 < natives.size() ? "," : ""));
			w.println("]}");
		}
		println("wrote " + out);
	}
}
