#!/usr/bin/env python3
"""
Version-tolerant installer for the lane-memcmp / NEON EXT patch.

    python3 apply_patch.py /path/to/ghidra-source-root          # apply
    python3 apply_patch.py /path/to/ghidra-source-root --check  # only report what would change

Edits are text-anchored (not line-number based), so it works on release tags and master.
It is idempotent: running it twice changes nothing the second time.
Touches: Decompiler cpp (simdidiom.{hh,cc} added; coreaction.cc, userop.{hh,cc}, Makefile) +
Decompiler/buildNatives.gradle + Processors/AARCH64/data/languages/AARCH64neon.sinc.
"""
import os, re, sys, shutil

def die(msg): print("ERROR:", msg); sys.exit(1)
root = sys.argv[1] if len(sys.argv) > 1 else die("usage: apply_patch.py <ghidra source root> [--check]")
check = "--check" in sys.argv
here = os.path.dirname(os.path.abspath(__file__))
cpp = os.path.join(root, "Ghidra/Features/Decompiler/src/decompile/cpp")
gradle = os.path.join(root, "Ghidra/Features/Decompiler/buildNatives.gradle")
sinc = os.path.join(root, "Ghidra/Processors/AARCH64/data/languages/AARCH64neon.sinc")
for p in (cpp, gradle, sinc):
    if not os.path.exists(p): die("not found (is this a Ghidra source root?): " + p)
changed = []

def edit(path, fn, label):
    s = open(path).read()
    t = fn(s)
    if t == s: print("  = %-34s already applied" % label); return
    changed.append(label); print("  + %-34s patched" % label)
    if not check:
        if not os.path.exists(path + ".orig"): shutil.copy(path, path + ".orig")
        open(path, "w").write(t)

def sub1(s, old, new, what):
    if old not in s: die("anchor not found for %s -- this Ghidra version differs; send me the file" % what)
    return s.replace(old, new, 1)

# ---- new files
for f in ("simdidiom.hh", "simdidiom.cc"):
    dst = os.path.join(cpp, f)
    new = open(os.path.join(here, "src", f)).read()
    if os.path.exists(dst) and open(dst).read() == new: print("  = %-34s already applied" % f)
    else:
        changed.append(f); print("  + %-34s %s" % (f, "written" if not check else "would be written"))
        if not check: open(dst, "w").write(new)

# ---- userop.hh / userop.cc : BUILTIN_MEMCMP
def userop_hh(s):
    if "BUILTIN_MEMCMP" in s: return s
    m = re.search(r"^(\s*static const uint4 BUILTIN_WCSNCPY;[^\n]*\n)", s, re.M)
    if not m: die("BUILTIN_WCSNCPY anchor missing in userop.hh")
    return s.replace(m.group(1), m.group(1) + "  static const uint4 BUILTIN_MEMCMP;\t\t///< Built-in id for memcmp\n", 1)
edit(os.path.join(cpp, "userop.hh"), userop_hh, "userop.hh")

def userop_cc(s):
    if "BUILTIN_MEMCMP" in s: return s
    m = re.search(r"^(const uint4 UserPcodeOp::BUILTIN_WCSNCPY = (0x[0-9a-fA-F]+);[^\n]*\n)", s, re.M)
    if not m: die("BUILTIN_WCSNCPY definition missing in userop.cc")
    used = set(int(x, 16) for x in re.findall(r"UserPcodeOp::BUILTIN_\w+ = (0x[0-9a-fA-F]+);", s))
    val = max(used) + 1
    s = s.replace(m.group(1), m.group(1) + "const uint4 UserPcodeOp::BUILTIN_MEMCMP = 0x%x;\n" % val, 1)
    case = '''    case UserPcodeOp::BUILTIN_MEMCMP:		// Compare two memory regions, returns int
    {
      int4 ptrSize = glb->types->getSizeOfPointer();
      int4 wordSize = glb->getDefaultDataSpace()->getWordSize();
      Datatype *vType = glb->types->getTypeVoid();
      Datatype *ptrType = glb->types->getTypePointer(ptrSize,vType,wordSize);
      Datatype *intType = glb->types->getBase(4,TYPE_INT);
      res = new DatatypeUserOp("builtin_memcmp",glb,UserPcodeOp::BUILTIN_MEMCMP,intType,ptrType,ptrType,intType);
      break;
    }
'''
    i = s.index("throw LowlevelError(\"Bad built-in userop id\")")
    j = s.rindex("    default:", 0, i)
    return s[:j] + case + s[j:]
edit(os.path.join(cpp, "userop.cc"), userop_cc, "userop.cc")

# ---- coreaction.cc : include, group, rule registration
def coreaction(s):
    if "RuleLaneMemcmp" in s: return s
    s = sub1(s, '#include "constseq.hh"\n', '#include "constseq.hh"\n#include "simdidiom.hh"\n', "coreaction include")
    s = sub1(s, '"constsequence",', '"constsequence", "lanememcmp",', "coreaction group list")
    m = re.search(r'^(\s*actcleanup->addRule\(\s*new RuleStringStore\("constsequence"\)\s*\);\s*\n)', s, re.M)
    if not m: die("RuleStringStore registration anchor missing in coreaction.cc")
    return s.replace(m.group(1), m.group(1) + '    actcleanup->addRule( new RuleLaneMemcmp("lanememcmp"));\n', 1)
edit(os.path.join(cpp, "coreaction.cc"), coreaction, "coreaction.cc")

# ---- Makefile / gradle
def makefile(s):
    if "simdidiom" in s: return s
    return sub1(s, "constseq", "constseq simdidiom", "Makefile source list")
edit(os.path.join(cpp, "Makefile"), makefile, "Makefile")

def gradle_fn(s):
    if "simdidiom.cc" in s: return s
    m = re.search(r'^([ \t]*)include "constseq.cc"[^\n]*\n', s, re.M)
    if not m: die("constseq.cc include missing in buildNatives.gradle")
    return s.replace(m.group(0), m.group(0) + m.group(1) + 'include "simdidiom.cc"\n', 1)
edit(gradle, gradle_fn, "buildNatives.gradle")

# ---- AARCH64 EXT lowering
def gen(nbytes, K):
    bits = nbytes * 8
    if nbytes == 16:
        reg, rn, rm, z = "Rd_VPR128.16B", "Rn_VPR128.16B", "Rm_VPR128.16B", "zext_zq(Zd);"
        pat = "is b_3131=0 & q=1 & b_2429=0x2e & b_2223=0b00 & b_2121=0 & Rm_VPR128.16B & b_1515=0 & imm4 & b_1114=%d & b_1010=0 & Rn_VPR128.16B & Rd_VPR128.16B & Zd" % K
    else:
        reg, rn, rm, z = "Rd_VPR64.8B", "Rn_VPR64.8B", "Rm_VPR64.8B", "zext_zd(Zd);"
        pat = "is b_3131=0 & q=0 & b_2429=0x2e & b_2223=0b00 & b_2121=0 & Rm_VPR64.8B & b_1415=0 & imm4 & b_1114=%d & b_1010=0 & Rn_VPR64.8B & Rd_VPR64.8B & Zd" % K
    o = ":ext %s, %s, %s, imm4\n%s\n{\n\t# EXT, constant byte index %d, as plain lane moves (no NEON_ext userop)\n" % (reg, rn, rm, pat, K)
    o += "\tlocal ext_n:%d = %s;\n\tlocal ext_m:%d = %s;\n" % (nbytes, rn, nbytes, rm)
    if K == 0: o += "\t%s = ext_n;\n" % reg
    else:
        o += "\t%s[0,%d] = ext_n[%d,%d];\n" % (reg, bits - 8 * K, 8 * K, bits - 8 * K)
        o += "\t%s[%d,%d] = ext_m[0,%d];\n" % (reg, bits - 8 * K, 8 * K, 8 * K)
    return o + "\t%s\n}\n\n" % z
def neon(s):
    if "EXT, constant byte index" in s: return s
    a = s.find("# C7.2.43 EXT page")
    if a < 0: die("EXT header anchor missing in AARCH64neon.sinc")
    t = s.find(":ext Rd_VPR64.8B, Rn_VPR64.8B, Rm_VPR64.8B, imm4\n", a)
    e = s.find("}\n", t) + 2
    old = s[a:e]
    if old.count(":ext ") != 2 or "NEON_ext" not in old: die("unexpected EXT block layout in AARCH64neon.sinc")
    new = "# C7.2.43 EXT (vector) -- native p-code: one constructor per constant index so the decompiler\n# sees ordinary lane moves instead of the opaque NEON_ext userop.\n\n"
    for K in range(16): new += gen(16, K)
    for K in range(8): new += gen(8, K)
    return s[:a] + new.rstrip("\n") + "\n" + s[e:]
edit(sinc, neon, "AARCH64neon.sinc")

print("\n%s %d file(s)." % ("Would change" if check else "Changed", len(changed)))
if changed and not check:
    print("Next: delete any AARCH64*.sla under Ghidra/Processors/AARCH64/data/languages (it recompiles on load),")
    print("rebuild the decompiler natives (make ghidra_opt / gradle) from THIS same tree, and use that tree's Java side.")
