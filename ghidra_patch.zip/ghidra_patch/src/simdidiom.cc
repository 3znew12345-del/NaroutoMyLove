/* ###
 * IP: GHIDRA
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#include "simdidiom.hh"
#include "funcdata.hh"
#include <algorithm>

namespace ghidra {

/// A slice of memory read by one lane: either directly addressed (stack/global) or through a pointer
struct LaneRef {
  AddrSpace *spc;	///< Space if directly addressed, otherwise null
  Varnode *ptr;		///< Pointer Varnode if read through a LOAD, otherwise null
  uintb off;		///< Byte offset (absolute in \b spc, or relative to \b ptr)
  int4 size;		///< Number of bytes
  PcodeOp *origin;	///< Op after which the memory value is fixed (null if never modified in function)
  bool sameBase(const LaneRef &b) const { return spc == b.spc && ptr == b.ptr; }
  int4 rank(void) const { return ptr != (Varnode *)0 ? 1 : (spc->getType() == IPTR_SPACEBASE ? 0 : 2); }
};

/// One lane comparison: memory slice \b a versus memory slice \b b
struct LanePair {
  LaneRef a;
  LaneRef b;
};

static const int4 MIN_TOTAL_BYTES = 8;	///< Minimum bytes compared before a memcmp is worth emitting
static const int4 MIN_RUN_BYTES = 4;	///< Every emitted memcmp must cover at least this many bytes
static const int4 MAX_RUNS = 8;		///< Maximum number of memcmp calls emitted for one tree
static const int4 MAX_LEAVES = 128;	///< Give up on trees bigger than this

/// Strip constant offsets (INT_ADD, PTRSUB, PTRADD, COPY, CAST) from a pointer, returning its root and the total offset
static Varnode *splitPointer(Varnode *ptr,uintb &off)
{
  off = 0;
  for(int4 i=0;i<16;++i) {
    if (!ptr->isWritten()) break;
    PcodeOp *d = ptr->getDef();
    OpCode c = d->code();
    if ((c == CPUI_INT_ADD || c == CPUI_PTRSUB) && d->getIn(1)->isConstant()) {
      off += d->getIn(1)->getOffset();
      ptr = d->getIn(0);
    }
    else if (c == CPUI_PTRADD && d->getIn(1)->isConstant() && d->getIn(2)->isConstant()) {
      off += d->getIn(1)->getOffset() * d->getIn(2)->getOffset();
      ptr = d->getIn(0);
    }
    else if (c == CPUI_COPY || c == CPUI_CAST)
      ptr = d->getIn(0);
    else
      break;
  }
  return ptr;
}

/// Resolve \b vn (read at byte \b extra, \b size bytes wide) to the memory it mirrors
static bool resolveMem(Varnode *vn,int4 size,uintb extra,LaneRef &res,int4 depth)
{
  if (depth > 6 || vn->isConstant()) return false;
  if (vn->isWritten()) {
    PcodeOp *def = vn->getDef();
    switch(def->code()) {
      case CPUI_LOAD:
	if (def->getIn(0)->getSpaceFromConst()->isBigEndian()) return false;
	{
	  uintb poff;
	  Varnode *root = splitPointer(def->getIn(1),poff);
	  if (root->isConstant()) return false;
	  res.spc = (AddrSpace *)0;
	  res.ptr = root;
	  res.off = extra + poff;
	}
	res.size = size;
	res.origin = def;
	return true;
      case CPUI_COPY:
	return resolveMem(def->getIn(0),size,extra,res,depth+1);
      case CPUI_SUBPIECE:
	if (!def->getIn(1)->isConstant()) return false;
	return resolveMem(def->getIn(0),size,extra + def->getIn(1)->getOffset(),res,depth+1);
      case CPUI_INT_RIGHT:
      {			// (x >> 8k) read at byte extra  ==  byte (extra+k) of x   (shift must stay inside x)
	Varnode *sh = def->getIn(1);
	if (!sh->isConstant() || (sh->getOffset() & 7) != 0) return false;
	uintb k = sh->getOffset() >> 3;
	if (extra + k + size > (uintb)def->getIn(0)->getSize()) return false;
	return resolveMem(def->getIn(0),size,extra + k,res,depth+1);
      }
      case CPUI_INDIRECT:
      case CPUI_MULTIEQUAL:
	break;			// Fall through to address based resolution
      default:
	return false;
    }
  }
  AddrSpace *spc = vn->getSpace();
  if (spc->isBigEndian()) return false;
  if (spc->getType() != IPTR_SPACEBASE && spc->getType() != IPTR_PROCESSOR) return false;
  if (spc->isOverlay() || spc->isReverseJustified()) return false;
  res.spc = spc;
  res.ptr = (Varnode *)0;
  res.off = vn->getOffset() + extra;
  res.size = size;
  res.origin = (PcodeOp *)0;
  if (vn->isWritten()) {
    PcodeOp *def = vn->getDef();
    if (def->code() != CPUI_INDIRECT) return false;	// MULTIEQUAL: unknown merge point, be conservative
    res.origin = PcodeOp::getOpFromConst(def->getIn(1)->getAddr());
  }
  return true;
}

/// Flatten a tree of \b andcode ops into its leaf Varnodes
static bool flattenTree(Varnode *vn,OpCode andcode,vector<Varnode *> &leaves,int4 depth)
{
  if (leaves.size() > MAX_LEAVES) return false;
  if (vn->isWritten()) {
    PcodeOp *def = vn->getDef();
    if (def->code() == andcode && (depth == 0 || vn->loneDescend() != (PcodeOp *)0)) {
      if (!flattenTree(def->getIn(0),andcode,leaves,depth+1)) return false;
      return flattenTree(def->getIn(1),andcode,leaves,depth+1);
    }
  }
  leaves.push_back(vn);
  return true;
}

/// Break an expression that must be zero into (x,y) XOR terms
static bool collectXorTerms(Varnode *vn,vector<pair<Varnode *,Varnode *> > &terms,int4 depth)
{
  if (depth > 8 || !vn->isWritten()) return false;
  PcodeOp *def = vn->getDef();
  if (def->code() == CPUI_INT_OR) {
    if (!collectXorTerms(def->getIn(0),terms,depth+1)) return false;
    return collectXorTerms(def->getIn(1),terms,depth+1);
  }
  if (def->code() == CPUI_INT_XOR) {
    terms.push_back(pair<Varnode *,Varnode *>(def->getIn(0),def->getIn(1)));
    return true;
  }
  return false;
}

/// Break a wide value that must be zero into (x,y) XOR terms
///
/// `v == 0` where v is built from OR, PIECE (concatenation), ZEXT and XOR: zero iff every XOR term is zero,
/// i.e. iff x == y for every (x,y).  This is the shape the decompiler leaves for vectorized compares.
static bool collectZero(Varnode *vn,vector<pair<Varnode *,Varnode *> > &terms,int4 depth,int4 &budget)
{
  if (depth > 40 || --budget < 0 || !vn->isWritten()) return false;
  PcodeOp *def = vn->getDef();
  switch(def->code()) {
    case CPUI_INT_OR:
    case CPUI_PIECE:
      if (!collectZero(def->getIn(0),terms,depth+1,budget)) return false;
      return collectZero(def->getIn(1),terms,depth+1,budget);
    case CPUI_INT_ZEXT:
      return collectZero(def->getIn(0),terms,depth+1,budget);
    case CPUI_INT_XOR:
      if (def->getIn(0)->isConstant() || def->getIn(1)->isConstant()) return false;
      terms.push_back(pair<Varnode *,Varnode *>(def->getIn(0),def->getIn(1)));
      return true;
    default:
      break;
  }
  return false;
}

/// Return \b true if nothing between \b start (exclusive) and \b end could write memory
static bool noInterference(PcodeOp *start,PcodeOp *end)
{
  if (start == (PcodeOp *)0) return true;
  if (start->getParent() != end->getParent()) return false;
  list<PcodeOp *>::iterator iter = start->getBasicIter();
  ++iter;
  list<PcodeOp *>::iterator enditer = end->getBasicIter();
  for(;iter!=enditer;++iter) {
    OpCode opc = (*iter)->code();
    if (opc == CPUI_STORE || opc == CPUI_CALL || opc == CPUI_CALLIND || opc == CPUI_CALLOTHER)
      return false;
  }
  return true;
}

static bool compareLanes(const LanePair &x,const LanePair &y)
{
  return x.a.off < y.a.off;
}

/// Build a pointer Varnode to the start of the given memory slice
static Varnode *buildPointer(Funcdata &data,const LaneRef &r,PcodeOp *insertPoint)
{
  TypeFactory *types = data.getArch()->types;
  if (r.ptr != (Varnode *)0) {
    if (r.off == 0) return r.ptr;
    Datatype *pt = r.ptr->getType();
    int4 elSize = 0;
    if (pt->getMetatype() == TYPE_PTR) elSize = ((TypePointer *)pt)->getPtrTo()->getAlignSize();
    if (elSize > 0 && (r.off % elSize) == 0) {
      PcodeOp *ptrAdd = data.newOp(3,insertPoint->getAddr());
      data.opSetOpcode(ptrAdd,CPUI_PTRADD);
      data.opSetInput(ptrAdd,r.ptr,0);
      data.opSetInput(ptrAdd,data.newConstant(r.ptr->getSize(),r.off / elSize),1);
      data.opSetInput(ptrAdd,data.newConstant(r.ptr->getSize(),elSize),2);
      Varnode *pout = data.newUniqueOut(r.ptr->getSize(),ptrAdd);
      pout->updateType(pt);
      data.opInsertBefore(ptrAdd,insertPoint);
      return pout;
    }
    PcodeOp *addOp = data.newOp(2,insertPoint->getAddr());
    data.opSetOpcode(addOp,CPUI_INT_ADD);
    data.opSetInput(addOp,r.ptr,0);
    data.opSetInput(addOp,data.newConstant(r.ptr->getSize(),r.off),1);
    Varnode *out = data.newUniqueOut(r.ptr->getSize(),addOp);
    out->updateType(pt);
    data.opInsertBefore(addOp,insertPoint);
    return out;
  }
  AddrSpace *spc = r.spc;
  Varnode *spacePtr;
  if (spc->getType() == IPTR_SPACEBASE)
    spacePtr = data.constructSpacebaseInput(spc);
  else
    spacePtr = data.constructConstSpacebase(spc);
  int4 ptrSize = spacePtr->getSize();
  uint4 ws = spc->getWordSize();
  auto *entry = data.getScopeLocal()->queryContainer(Address(spc,r.off),r.size,Address());	// SymbolEntry (<=12.0) / MapEntry (master)
  Datatype *baseType;
  uintb baseOff = r.off;
  if (entry != nullptr) {
    baseType = entry->getSymbol()->getType();
    baseOff = entry->getFirst();
  }
  else
    baseType = types->getBase(1,TYPE_UINT);
  PcodeOp *ptrsub = data.newOp(2,insertPoint->getAddr());
  data.opSetOpcode(ptrsub,CPUI_PTRSUB);
  data.opSetInput(ptrsub,spacePtr,0);
  data.opSetInput(ptrsub,data.newConstant(ptrSize,AddrSpace::byteToAddress(baseOff,ws)),1);
  Varnode *cur = data.newUniqueOut(ptrSize,ptrsub);
  TypePointer *ptype = types->getTypePointerStripArray(ptrSize,baseType,ws);
  cur->updateType(ptype);
  data.opInsertBefore(ptrsub,insertPoint);
  uintb delta = r.off - baseOff;
  if (delta != 0) {
    Datatype *elType = ptype->getPtrTo();
    int4 elSize = elType->getAlignSize();
    if (elSize <= 0 || (delta % elSize) != 0) {
      // Fall back to byte arithmetic
      PcodeOp *addOp = data.newOp(2,insertPoint->getAddr());
      data.opSetOpcode(addOp,CPUI_INT_ADD);
      data.opSetInput(addOp,cur,0);
      data.opSetInput(addOp,data.newConstant(ptrSize,delta),1);
      Varnode *out = data.newUniqueOut(ptrSize,addOp);
      out->updateType(ptype);
      data.opInsertBefore(addOp,insertPoint);
      return out;
    }
    PcodeOp *ptrAdd = data.newOp(3,insertPoint->getAddr());
    data.opSetOpcode(ptrAdd,CPUI_PTRADD);
    data.opSetInput(ptrAdd,cur,0);
    data.opSetInput(ptrAdd,data.newConstant(ptrSize,delta / elSize),1);
    data.opSetInput(ptrAdd,data.newConstant(ptrSize,elSize),2);
    Varnode *out = data.newUniqueOut(ptrSize,ptrAdd);
    out->updateType(ptype);
    data.opInsertBefore(ptrAdd,insertPoint);
    cur = out;
  }
  return cur;
}

void RuleLaneMemcmp::getOpList(vector<uint4> &oplist) const

{
  oplist.push_back(CPUI_BOOL_AND);
  oplist.push_back(CPUI_BOOL_OR);
  oplist.push_back(CPUI_INT_EQUAL);
  oplist.push_back(CPUI_INT_NOTEQUAL);
}

int4 RuleLaneMemcmp::applyOp(PcodeOp *op,Funcdata &data)

{
  OpCode opc = op->code();
  OpCode treecode,leafcode;
  Varnode *outvn = op->getOut();
  vector<pair<Varnode *,Varnode *> > terms;

  if (opc == CPUI_INT_EQUAL || opc == CPUI_INT_NOTEQUAL) {
    // Shape 1: wide  (OR/PIECE/XOR tree) == 0
    Varnode *expr;
    if (op->getIn(1)->constantMatch(0)) expr = op->getIn(0);
    else if (op->getIn(0)->constantMatch(0)) expr = op->getIn(1);
    else return 0;
    if (!expr->isWritten()) return 0;
    OpCode ec = expr->getDef()->code();
    if (ec != CPUI_INT_OR && ec != CPUI_PIECE && ec != CPUI_INT_XOR && ec != CPUI_INT_ZEXT) return 0;
    int4 budget = MAX_LEAVES;
    if (!collectZero(expr,terms,0,budget)) return 0;
    leafcode = opc;
    treecode = (opc == CPUI_INT_EQUAL) ? CPUI_BOOL_AND : CPUI_BOOL_OR;
  }
  else {
    // Shape 2: BOOL_AND tree of per-lane (x ^ y) == 0   (or BOOL_OR tree of != 0)
    treecode = opc;
    leafcode = (treecode == CPUI_BOOL_AND) ? CPUI_INT_EQUAL : CPUI_INT_NOTEQUAL;
    PcodeOp *parent = outvn->loneDescend();
    if (parent != (PcodeOp *)0 && parent->code() == treecode) return 0;	// Only act on the root of the tree
    vector<Varnode *> leaves;
    if (!flattenTree(outvn,treecode,leaves,0)) return 0;
    if (leaves.size() < 2) return 0;
    for(int4 i=0;i<leaves.size();++i) {
      Varnode *lvn = leaves[i];
      if (!lvn->isWritten()) return 0;
      PcodeOp *cmp = lvn->getDef();
      if (cmp->code() != leafcode) return 0;
      Varnode *l0 = cmp->getIn(0);
      Varnode *l1 = cmp->getIn(1);
      if (l1->constantMatch(0)) {
	int4 budget = MAX_LEAVES;
	if (!collectZero(l0,terms,0,budget)) return 0;
      }
      else if (l0->constantMatch(0)) {
	int4 budget = MAX_LEAVES;
	if (!collectZero(l1,terms,0,budget)) return 0;
      }
      else if (!l0->isConstant() && !l1->isConstant())
	terms.push_back(pair<Varnode *,Varnode *>(l0,l1));
      else
	return 0;
    }
  }
  if (terms.size() < 2 || terms.size() > MAX_LEAVES) return 0;

  // Resolve every term to a pair of memory slices
  vector<LanePair> pairs;
  for(int4 j=0;j<terms.size();++j) {
    LanePair lp;
    int4 sz = terms[j].first->getSize();
    if (sz != terms[j].second->getSize()) return 0;
    if (!resolveMem(terms[j].first,sz,0,lp.a,0)) return 0;
    if (!resolveMem(terms[j].second,sz,0,lp.b,0)) return 0;
    pairs.push_back(lp);
  }
  if (pairs.size() < 2) return 0;

  // Orient every pair consistently: side 'a' has the lowest ranked base of the first pair
  if (pairs[0].a.rank() > pairs[0].b.rank())
    std::swap(pairs[0].a,pairs[0].b);
  LaneRef baseA = pairs[0].a;
  LaneRef baseB = pairs[0].b;
  if (baseA.sameBase(baseB)) return 0;		// Both sides same region: not a comparison of two buffers
  for(int4 i=1;i<pairs.size();++i) {
    LanePair &lp(pairs[i]);
    if (lp.a.sameBase(baseA) && lp.b.sameBase(baseB)) continue;
    if (lp.b.sameBase(baseA) && lp.a.sameBase(baseB)) {
      std::swap(lp.a,lp.b);
      continue;
    }
    return 0;
  }

  // Memory must not change between where the values were fixed and the tree root
  for(int4 i=0;i<pairs.size();++i) {
    if (!noInterference(pairs[i].a.origin,op)) return 0;
    if (!noInterference(pairs[i].b.origin,op)) return 0;
  }

  // Tile into contiguous runs
  sort(pairs.begin(),pairs.end(),compareLanes);
  struct Run { int4 first; int4 count; int4 bytes; };
  vector<Run> runs;
  int4 total = 0;
  for(int4 i=0;i<pairs.size();++i) {
    const LanePair &lp(pairs[i]);
    bool extend = false;
    if (!runs.empty()) {
      const LanePair &prev(pairs[i-1]);
      if (prev.a.off == lp.a.off) return 0;			// Duplicate lane
      if (prev.a.off + prev.a.size > lp.a.off) return 0;	// Overlap
      extend = (prev.a.off + prev.a.size == lp.a.off) && (prev.b.off + prev.b.size == lp.b.off);
    }
    if (extend) {
      runs.back().count += 1;
      runs.back().bytes += lp.a.size;
    }
    else {
      Run r;
      r.first = i; r.count = 1; r.bytes = lp.a.size;
      runs.push_back(r);
    }
    total += lp.a.size;
  }
  if (total < MIN_TOTAL_BYTES) return 0;
  if (runs.size() > MAX_RUNS) return 0;
  for(int4 i=0;i<runs.size();++i)
    if (runs[i].bytes < MIN_RUN_BYTES) return 0;	// Lanes not tiling into real buffers: not a memcmp

  // Build the replacement
  Architecture *glb = data.getArch();
  glb->userops.registerBuiltin(UserPcodeOp::BUILTIN_MEMCMP);
  Varnode *result = (Varnode *)0;
  for(int4 i=0;i<runs.size();++i) {
    const LanePair &lp(pairs[runs[i].first]);
    Varnode *pa = buildPointer(data,lp.a,op);
    Varnode *pb = buildPointer(data,lp.b,op);
    PcodeOp *callOp = data.newOp(4,op->getAddr());
    data.opSetOpcode(callOp,CPUI_CALLOTHER);
    data.opSetInput(callOp,data.newConstant(4,UserPcodeOp::BUILTIN_MEMCMP),0);
    data.opSetInput(callOp,pa,1);
    data.opSetInput(callOp,pb,2);
    Varnode *lenVn = data.newConstant(4,runs[i].bytes);
    lenVn->updateType(callOp->inputTypeLocal(3));
    data.opSetInput(callOp,lenVn,3);
    Varnode *callOut = data.newUniqueOut(4,callOp);
    callOut->updateType(glb->types->getBase(4,TYPE_INT));
    data.opInsertBefore(callOp,op);
    PcodeOp *cmpOp = data.newOp(2,op->getAddr());
    data.opSetOpcode(cmpOp,leafcode);
    data.opSetInput(cmpOp,callOut,0);
    data.opSetInput(cmpOp,data.newConstant(4,0),1);
    Varnode *boolVn = data.newUniqueOut(1,cmpOp);
    boolVn->updateType(glb->types->getBase(1,TYPE_BOOL));
    data.opInsertBefore(cmpOp,op);
    if (result == (Varnode *)0)
      result = boolVn;
    else {
      PcodeOp *joinOp = data.newOp(2,op->getAddr());
      data.opSetOpcode(joinOp,treecode);
      data.opSetInput(joinOp,result,0);
      data.opSetInput(joinOp,boolVn,1);
      result = data.newUniqueOut(1,joinOp);
      result->updateType(glb->types->getBase(1,TYPE_BOOL));
      data.opInsertBefore(joinOp,op);
    }
  }
  data.totalReplace(outvn,result);
  vector<PcodeOp *> scratch;
  data.opDestroyRecursive(op,scratch);
  return 1;
}

} // End namespace ghidra
