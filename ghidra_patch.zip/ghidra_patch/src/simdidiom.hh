/* ###
 * IP: GHIDRA
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
/// \file simdidiom.hh
/// \brief Collapse lane-wise "all bytes equal" boolean trees into memcmp
#ifndef __SIMDIDIOM_HH__
#define __SIMDIDIOM_HH__

#include "ruleaction.hh"

namespace ghidra {

/// \brief Replace a boolean tree of per-lane equality tests with builtin memcmp calls
///
/// Matches the root of a BOOL_AND tree (or BOOL_OR tree of INT_NOTEQUAL leaves) whose leaves are
/// `(x ^ y) == 0`, `(x ^ y | z ^ w) == 0` or `x == y`, where every x,y is a slice of memory
/// (a SUBPIECE of a stack/global Varnode or of a LOAD).  If the slices of both sides tile
/// contiguous regions, the tree becomes `builtin_memcmp(p, q, n) == 0` (one call per contiguous run).
class RuleLaneMemcmp : public Rule {
public:
  RuleLaneMemcmp(const string &g) : Rule(g, 0, "lanememcmp") {}	///< Constructor
  virtual Rule *clone(const ActionGroupList &grouplist) const {
    if (!grouplist.contains(getGroup())) return (Rule *)0;
    return new RuleLaneMemcmp(getGroup());
  }
  virtual void getOpList(vector<uint4> &oplist) const;
  virtual int4 applyOp(PcodeOp *op,Funcdata &data);
};

} // End namespace ghidra
#endif
